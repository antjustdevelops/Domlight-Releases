@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_DOMLIGHT_FINAL.ps1"
endlocal
