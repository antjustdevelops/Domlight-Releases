﻿param(
    [Parameter(Mandatory=$true)][string]$ReceiptsDir,
    [Parameter(Mandatory=$true)][string]$ResultFile,
    [Parameter(Mandatory=$true)][string]$ErrorFile
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $Root "PdfEngine.ps1")

$months = @{
    "январ"=1; "феврал"=2; "март"=3; "апрел"=4; "май"=5; "мая"=5; "июн"=6;
    "июл"=7; "август"=8; "сентябр"=9; "октябр"=10; "ноябр"=11; "декабр"=12
}

function Get-OriginalReceiptFileName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return $Name }

    # Files previously moved to "Не распознано" are named:
    # <reason>__<original filename>. Recover the original technical name.
    $idx = $Name.LastIndexOf('__')
    if ($idx -ge 0 -and ($idx + 2) -lt $Name.Length) {
        return $Name.Substring($idx + 2)
    }
    return $Name
}

function Get-PeriodFromName([string]$Name) {
    $Name = Get-OriginalReceiptFileName $Name
    $m = [regex]::Match($Name, '^(?<y>20\d{2})[_-](?<m>0[1-9]|1[0-2])[_-]')
    if ($m.Success) { return [pscustomobject]@{Year=[int]$m.Groups['y'].Value;Month=[int]$m.Groups['m'].Value;Key=([int]$m.Groups['y'].Value*100+[int]$m.Groups['m'].Value)} }
    return $null
}


function Get-ReceiptTypeFromName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return 'Не определено' }
    $Name = Get-OriginalReceiptFileName $Name

    # Portal technical filenames use:
    # YYYY_MM_1_ACCOUNT_....pdf = ЖКХ
    # YYYY_MM_2_ACCOUNT_....pdf = Капремонт
    $m = [regex]::Match($Name, '^20\d{2}[_-](?:0[1-9]|1[0-2])[_-](?<kind>[12])[_-]', 'IgnoreCase')
    if ($m.Success) {
        if ($m.Groups['kind'].Value -eq '1') { return 'ЖКХ' }
        if ($m.Groups['kind'].Value -eq '2') { return 'Капремонт' }
    }

    if ($Name -match '(?i)_ЖКХ_') { return 'ЖКХ' }
    if ($Name -match '(?i)_Капремонт_') { return 'Капремонт' }

    return 'Не определено'
}

function Get-ArchiveAccountApartmentMap {
    param([string]$ArchiveRoot)

    $map = @{}
    foreach ($dir in @(Get-ChildItem -LiteralPath $ArchiveRoot -Directory -ErrorAction SilentlyContinue)) {
        if ($dir.Name -eq 'Не распознано') { continue }

        $account = Get-AccountFromFolderName $dir.Name
        $apt = Get-ApartmentFromFolderName $dir.Name
        if (-not [string]::IsNullOrWhiteSpace($account) -and
            -not [string]::IsNullOrWhiteSpace($apt)) {
            $map[$account] = $apt
        }
    }
    return $map
}

function Normalize-ReceiptText([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) {
        return [pscustomobject]@{ Normal=''; Compact='' }
    }

    $normal = ($Text -replace '[\u0000-\u001F]+',' ' -replace '\s+',' ').Trim().ToLowerInvariant()
    $compact = ($normal -replace '[^0-9a-zа-яё]+','')
    return [pscustomobject]@{ Normal=$normal; Compact=$compact }
}

function Get-PeriodFromText([string]$Text) {
    $n = Normalize-ReceiptText $Text
    $normal = $n.Normal
    $compact = $n.Compact

    $m = [regex]::Match($normal, '(?i)\bза\s+(?<month>январ\w*|феврал\w*|март\w*|апрел\w*|ма[йя]|июн\w*|июл\w*|август\w*|сентябр\w*|октябр\w*|ноябр\w*|декабр\w*)\s+(?<year>20\d{2})\s*г')
    if ($m.Success) {
        $word = $m.Groups['month'].Value.ToLowerInvariant()
        $month = $null
        foreach ($k in $months.Keys) {
            if ($word.StartsWith($k)) { $month = $months[$k]; break }
        }
        if ($month) {
            $year = [int]$m.Groups['year'].Value
            return [pscustomobject]@{Year=$year;Month=[int]$month;Key=($year*100+[int]$month)}
        }
    }

    # Fallback for letter-stream text where spaces/order were lost.
    foreach ($k in $months.Keys) {
        $pattern = [regex]::Escape($k) + '\w{0,8}(20\d{2})г?'
        $cm = [regex]::Match($compact, $pattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($cm.Success) {
            $year = [int]$cm.Groups[1].Value
            $month = $months[$k]
            return [pscustomobject]@{Year=$year;Month=[int]$month;Key=($year*100+[int]$month)}
        }
    }

    return $null
}

function Get-Apartment([string]$Text) {
    $n = Normalize-ReceiptText $Text
    $normal = $n.Normal
    $compact = $n.Compact

    $patterns = @(
        '(?i)\bадрес\s*:\s*.*?\bапарт\.?\s*([0-9]+[0-9a-zа-яё-]*)',
        '(?i)\bапарт\.?\s*([0-9]+[0-9a-zа-яё-]*)',
        '(?i)\bапартамент(?:а|ов)?\s*([0-9]+[0-9a-zа-яё-]*)',
        '(?i)\bкв(?:артира)?\.?\s*([0-9]+[0-9a-zа-яё-]*)'
    )
    foreach ($pattern in $patterns) {
        $m = [regex]::Match($normal, $pattern)
        if ($m.Success) { return $m.Groups[1].Value.ToUpperInvariant() }
    }

    # Compact fallback catches streams such as "...апарт129е...".
    $compactPatterns = @(
        'апарт(?:амент(?:а|ов)?)?([0-9]+[0-9a-zа-яё-]*)',
        'квартира([0-9]+[0-9a-zа-яё-]*)'
    )
    foreach ($pattern in $compactPatterns) {
        $m = [regex]::Match($compact, $pattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($m.Success) { return $m.Groups[1].Value.ToUpperInvariant() }
    }

    return ''
}

function Get-AccountFromName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
    $Name = Get-OriginalReceiptFileName $Name

    # Domlight personal accounts currently look like 11-digit numbers.
    # Keep the pattern somewhat broader for future accounts while avoiding year/month fragments.
    $m = [regex]::Match($Name, '(?<!\d)(?<account>\d{9,20})(?!\d)')
    if ($m.Success) { return [string]$m.Groups['account'].Value }
    return ''
}

function Get-AccountFromText([string]$Text) {
    $n = Normalize-ReceiptText $Text
    $normal = $n.Normal
    $compact = $n.Compact

    $patterns = @(
        '(?i)лицев(?:ой|евого)\s*(?:счет|сч[её]т|сч[её]та)\s*[:№#-]?\s*(\d{9,20})',
        '(?i)л\.?\s*с\.?\s*[:№#-]?\s*(\d{9,20})'
    )
    foreach ($pattern in $patterns) {
        $m = [regex]::Match($normal, $pattern)
        if ($m.Success) { return [string]$m.Groups[1].Value }
    }

    $m = [regex]::Match($compact, 'лицев(?:ой|евого)(?:счет|счёт|счета)(\d{9,20})', 'IgnoreCase')
    if ($m.Success) { return [string]$m.Groups[1].Value }

    return ''
}

function Get-AccountFromFolderName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }

    $m = [regex]::Match($Name, '^(?<account>\d{9,20})(?:\s+-\s+кв\.\s+.+)?$', 'IgnoreCase')
    if ($m.Success) { return [string]$m.Groups['account'].Value }
    return ''
}

function Get-ApartmentFromFolderName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }

    $m = [regex]::Match($Name, '^\d{9,20}\s+-\s+кв\.\s+(?<apt>.+)$', 'IgnoreCase')
    if ($m.Success) { return ([string]$m.Groups['apt'].Value).Trim().ToUpperInvariant() }
    return ''
}


function Get-ReceiptType([string]$Text) {
    $n = Normalize-ReceiptText $Text
    $normal = $n.Normal
    $compact = $n.Compact

    # Capital repair first, because those PDFs can also contain generic utility words.
    $hasCapital = ($compact -match 'капитальн')
    $hasRepair = ($compact -match 'ремонт')
    if ($hasCapital -and $hasRepair) {
        return 'Капремонт'
    }

    # ЖКХ is identified from the PDF content, not the personal account number.
    $jkhSignals = 0
    if ($compact -match 'коммунальн') { $jkhSignals++ }
    if ($compact -match 'электроснабж') { $jkhSignals++ }
    if ($compact -match 'водоснабж') { $jkhSignals++ }
    if ($compact -match 'водоотвед') { $jkhSignals++ }
    if ($compact -match 'содержание') { $jkhSignals++ }
    if ($compact -match 'консьерж') { $jkhSignals++ }
    if ($compact -match 'обращениес(?:тко|тко)') { $jkhSignals++ }

    if ($jkhSignals -ge 2) {
        return 'ЖКХ'
    }

    # Strong single phrase fallback.
    if ($normal -match 'предоставлен\w*\s+коммунальн\w*\s+услуг') {
        return 'ЖКХ'
    }

    return 'Не определено'
}


function Safe-ReceiptNamePart {
    param([string]$Text)

    $value = ([string]$Text).Trim()
    foreach ($bad in [IO.Path]::GetInvalidFileNameChars()) {
        $value = $value.Replace([string]$bad, '_')
    }
    return $value
}

function Test-SameFileContent {
    param([string]$PathA, [string]$PathB)

    try {
        if (-not (Test-Path -LiteralPath $PathA) -or -not (Test-Path -LiteralPath $PathB)) { return $false }
        $a = Get-Item -LiteralPath $PathA -ErrorAction Stop
        $b = Get-Item -LiteralPath $PathB -ErrorAction Stop
        if ($a.Length -ne $b.Length) { return $false }

        $ha = (Get-FileHash -LiteralPath $PathA -Algorithm SHA256 -ErrorAction Stop).Hash
        $hb = (Get-FileHash -LiteralPath $PathB -Algorithm SHA256 -ErrorAction Stop).Hash
        return ($ha -eq $hb)
    }
    catch {
        return $false
    }
}

function Get-UniqueFilePath {
    param([string]$DesiredPath)

    if (-not (Test-Path -LiteralPath $DesiredPath)) { return $DesiredPath }

    $dir = Split-Path -Parent $DesiredPath
    $base = [IO.Path]::GetFileNameWithoutExtension($DesiredPath)
    $ext = [IO.Path]::GetExtension($DesiredPath)
    $n = 2
    do {
        $candidate = Join-Path $dir ($base + '_' + $n + $ext)
        $n++
    } while (Test-Path -LiteralPath $candidate)

    return $candidate
}

function Move-ToUnrecognized {
    param(
        [string]$ArchiveRoot,
        [string]$FilePath,
        [string]$Reason
    )

    if (-not (Test-Path -LiteralPath $FilePath)) { return $null }

    $dir = Join-Path $ArchiveRoot 'Не распознано'
    New-Item -ItemType Directory -Force -Path $dir | Out-Null

    $original = [IO.Path]::GetFileName($FilePath)
    $reasonPart = Safe-ReceiptNamePart $Reason
    if ($reasonPart.Length -gt 45) { $reasonPart = $reasonPart.Substring(0,45) }
    $desired = Join-Path $dir ($reasonPart + '__' + $original)

    if (Test-Path -LiteralPath $desired) {
        if (Test-SameFileContent -PathA $FilePath -PathB $desired) {
            Remove-Item -LiteralPath $FilePath -Force -ErrorAction SilentlyContinue
            return $desired
        }
        $desired = Get-UniqueFilePath $desired
    }

    try {
        Move-Item -LiteralPath $FilePath -Destination $desired -Force -ErrorAction Stop
        return $desired
    }
    catch {
        return $null
    }
}

function Move-ReceiptToTypeFolder {
    param(
        [string]$AccountFolder,
        [string]$Account,
        [string]$Apartment,
        [string]$Type,
        [int]$Year,
        [int]$Month,
        [string]$FilePath
    )

    if ([string]::IsNullOrWhiteSpace($AccountFolder) -or
        [string]::IsNullOrWhiteSpace($Type) -or
        [string]::IsNullOrWhiteSpace($FilePath) -or
        -not (Test-Path -LiteralPath $FilePath)) {
        return $FilePath
    }

    if ($Type -notin @('ЖКХ','Капремонт')) {
        return $FilePath
    }

    $safeAccount = Safe-ReceiptNamePart $Account
    $safeApartment = Safe-ReceiptNamePart $Apartment

    # The subfolder is self-explanatory even when viewed/copied separately.
    $suffix = ' - ЛС ' + $safeAccount
    if (-not [string]::IsNullOrWhiteSpace($safeApartment)) {
        $suffix += ' - кв. ' + $safeApartment
    }

    $subfolderName = $Type + $suffix
    $destDir = Join-Path $AccountFolder $subfolderName
    New-Item -ItemType Directory -Force -Path $destDir | Out-Null

    # Keep YYYY_MM at the beginning so fast month detection continues to work.
    $newName = ('{0:D4}_{1:D2}_{2}' -f $Year,$Month,$Type)
    if (-not [string]::IsNullOrWhiteSpace($safeApartment)) {
        $newName += '_кв_' + $safeApartment
    }
    $newName += '_ЛС_' + $safeAccount + '.pdf'

    $dest = Join-Path $destDir $newName
    $sourceFull = [IO.Path]::GetFullPath($FilePath)
    $destFull = [IO.Path]::GetFullPath($dest)

    if ($sourceFull -eq $destFull) {
        return $dest
    }

    # Never delete a source merely because another PDF has the same byte length.
    # Delete only after an exact SHA-256 match; otherwise keep both with a unique name.
    if (Test-Path -LiteralPath $dest) {
        if (Test-SameFileContent -PathA $FilePath -PathB $dest) {
            if ($sourceFull -ne $destFull) {
                Remove-Item -LiteralPath $FilePath -Force -ErrorAction SilentlyContinue
            }
            return $dest
        }
        $dest = Get-UniqueFilePath $dest
    }

    try {
        Move-Item -LiteralPath $FilePath -Destination $dest -Force -ErrorAction Stop
        return $dest
    }
    catch {
        return $FilePath
    }
}

function Organize-ReceiptArchive {
    param([string]$ArchiveRoot)

    $stats = [ordered]@{
        Organized = 0
        Unrecognized = 0
        Errors = 0
        FastClassified = 0
        PdfRead = 0
    }

    $unrecognizedDir = Join-Path $ArchiveRoot 'Не распознано'
    $accountApartmentMap = Get-ArchiveAccountApartmentMap -ArchiveRoot $ArchiveRoot

    # IMPORTANT:
    # Most historical Domlight PDFs already contain period, kind and account in the filename,
    # and apartment is present in the account-folder name. Use that metadata first.
    # Only open/read PDF text when something is genuinely missing.
    # Retry EVERY PDF, including files previously put into "Не распознано".
    # Earlier versions could misclassify normal receipts; v72 must recover them automatically.
    $pdfs = @(
        Get-ChildItem -LiteralPath $ArchiveRoot -Recurse -Filter *.pdf -File -ErrorAction SilentlyContinue
    )

    foreach ($f in $pdfs) {
        try {
            $period = Get-PeriodFromName $f.Name
            $type = Get-ReceiptTypeFromName $f.Name
            $account = Get-AccountFromName $f.Name
            $apt = ''

            # Look through ancestors for account/apartment and legacy type folder.
            $dir = Get-Item -LiteralPath (Split-Path -Parent $f.FullName) -ErrorAction SilentlyContinue
            while ($dir -and $dir.FullName.StartsWith($ArchiveRoot, [StringComparison]::OrdinalIgnoreCase)) {
                if ([string]::IsNullOrWhiteSpace($account)) {
                    $account = Get-AccountFromFolderName $dir.Name
                }
                if ([string]::IsNullOrWhiteSpace($apt)) {
                    $apt = Get-ApartmentFromFolderName $dir.Name
                }

                if ($type -eq 'Не определено') {
                    if ($dir.Name -match '^(?i)ЖКХ(?:\s|$)') { $type = 'ЖКХ' }
                    elseif ($dir.Name -match '^(?i)Капремонт(?:\s|$)') { $type = 'Капремонт' }
                }

                if ($dir.FullName -eq $ArchiveRoot) { break }
                $dir = $dir.Parent
            }

            # If a loose/root PDF has the account in its filename, recover apartment
            # from the already existing account folder.
            if ([string]::IsNullOrWhiteSpace($apt) -and
                -not [string]::IsNullOrWhiteSpace($account) -and
                $accountApartmentMap.ContainsKey($account)) {
                $apt = [string]$accountApartmentMap[$account]
            }

            $needPdfRead = (
                -not $period -or
                $type -eq 'Не определено' -or
                [string]::IsNullOrWhiteSpace($account) -or
                [string]::IsNullOrWhiteSpace($apt)
            )

            if ($needPdfRead) {
                # Slow fallback only for atypical files. Normal historical files never come here.
                $pdfText = Get-PdfTextDirect $f.FullName
                $stats.PdfRead++

                if (-not [string]::IsNullOrWhiteSpace($pdfText)) {
                    if (-not $period) { $period = Get-PeriodFromText $pdfText }
                    if ($type -eq 'Не определено') { $type = Get-ReceiptType $pdfText }
                    if ([string]::IsNullOrWhiteSpace($account)) { $account = Get-AccountFromText $pdfText }
                    if ([string]::IsNullOrWhiteSpace($apt)) { $apt = Get-Apartment $pdfText }
                }
            }
            else {
                $stats.FastClassified++
            }

            $missing = @()
            if ($type -notin @('ЖКХ','Капремонт')) { $missing += 'тип' }
            if ([string]::IsNullOrWhiteSpace($account)) { $missing += 'ЛС' }
            if ([string]::IsNullOrWhiteSpace($apt)) { $missing += 'квартира' }
            if (-not $period) { $missing += 'период' }

            if ($missing.Count -gt 0) {
                $alreadyUnrecognized = $f.FullName.StartsWith($unrecognizedDir + '\', [StringComparison]::OrdinalIgnoreCase)
                if (-not $alreadyUnrecognized) {
                    [void](Move-ToUnrecognized `
                        -ArchiveRoot $ArchiveRoot `
                        -FilePath $f.FullName `
                        -Reason ('нет ' + ($missing -join '+')))
                }
                $stats.Unrecognized++
                continue
            }

            $safeApartment = Safe-ReceiptNamePart $apt
            $accountFolderName = $account + ' - кв. ' + $safeApartment
            $accountFolder = Join-Path $ArchiveRoot $accountFolderName
            New-Item -ItemType Directory -Force -Path $accountFolder | Out-Null
            $accountApartmentMap[$account] = $apt

            $before = [IO.Path]::GetFullPath($f.FullName)
            $after = Move-ReceiptToTypeFolder `
                -AccountFolder $accountFolder `
                -Account $account `
                -Apartment $apt `
                -Type $type `
                -Year ([int]$period.Year) `
                -Month ([int]$period.Month) `
                -FilePath $f.FullName

            if ($after -and ([IO.Path]::GetFullPath($after) -ne $before)) {
                $stats.Organized++
            }
        }
        catch {
            $stats.Errors++
            # Do not block startup because one old PDF is inaccessible/cloud-only.
            # Leave that file in place so it can be retried later.
        }
    }

    # Cleanup empty obsolete folders bottom-up.
    $dirs = @(
        Get-ChildItem -LiteralPath $ArchiveRoot -Recurse -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -ne $unrecognizedDir } |
        Sort-Object { $_.FullName.Length } -Descending
    )

    foreach ($dir in $dirs) {
        try {
            $children = @(Get-ChildItem -LiteralPath $dir.FullName -Force -ErrorAction Stop)
            if ($children.Count -eq 0) {
                Remove-Item -LiteralPath $dir.FullName -Force -ErrorAction Stop
            }
        } catch {}
    }

    # Explicit cleanup of old generic type folders.
    foreach ($legacy in @(Get-ChildItem -LiteralPath $ArchiveRoot -Recurse -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -in @('ЖКХ','Капремонт') } |
        Sort-Object { $_.FullName.Length } -Descending)) {
        try {
            $remaining = @(Get-ChildItem -LiteralPath $legacy.FullName -Force -ErrorAction SilentlyContinue)
            if ($remaining.Count -eq 0) {
                Remove-Item -LiteralPath $legacy.FullName -Recurse -Force -ErrorAction Stop
            }
        } catch {}
    }

    return [pscustomobject]$stats
}

try {
    if (-not (Test-Path $ReceiptsDir)) { throw "Папка квитанций не найдена: $ReceiptsDir" }

    # v74: Mailing is read-only. Download/check is responsible for organizing receipts.
    $migration = [pscustomobject]@{ Organized=0; Unrecognized=0; Errors=0; FastClassified=0; PdfRead=0 }
    $unrecognizedDir = Join-Path $ReceiptsDir 'Не распознано'
    # Fast latest-month scan: enumerate PDFs, but never open historical PDFs just for migration.
    $all = @(Get-ChildItem $ReceiptsDir -Recurse -Filter *.pdf -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notlike ($unrecognizedDir + '\*') })
    if ($all.Count -eq 0) { throw "В архиве нет PDF-квитанций." }

    # Fast path: Domlight filenames already contain YYYY_MM. This is used ONLY to select the newest month,
    # never to decide ЖКХ vs капремонт.
    $named = @()
    foreach ($f in $all) {
        $p = Get-PeriodFromName $f.Name
        if ($p) { $named += [pscustomobject]@{File=$f;Period=$p} }
    }

    $latest = $null
    if ($named.Count -gt 0) {
        $latest = ($named | Sort-Object {$_.Period.Key} -Descending | Select-Object -First 1).Period
    } else {
        # Rare fallback: inspect only the newest few files per account, not the whole archive.
        $periods = @()
        foreach ($folder in @(Get-ChildItem $ReceiptsDir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'Не распознано' })) {
            foreach ($f in @(Get-ChildItem $folder.FullName -Recurse -Filter *.pdf -File | Sort-Object LastWriteTime -Descending | Select-Object -First 4)) {
                try {
                    $txt = Get-PdfTextDirect $f.FullName
                    $p = Get-PeriodFromText $txt
                    if ($p) { $periods += $p }
                } catch {}
            }
        }
        if ($periods.Count -eq 0) { throw "Не удалось определить расчётный месяц в квитанциях." }
        $latest = $periods | Sort-Object Key -Descending | Select-Object -First 1
    }

    $items = @()
    $capItems = @()
    $errors = @()
    $capCount = 0
    $unknownCount = [int]$migration.Unrecognized
    $readErrorCount = 0
    $blankTextCount = 0
    $folders = @(Get-ChildItem $ReceiptsDir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'Не распознано' })

    foreach ($folder in $folders) {
        $account = [string]$folder.Name
        $nameMatch = [regex]::Match($account, '^(?<account>.+?)\s+-\s+кв\.\s+.+$', 'IgnoreCase')
        if ($nameMatch.Success) {
            $account = [string]$nameMatch.Groups['account'].Value
        }
        $files = @(Get-ChildItem $folder.FullName -Recurse -Filter *.pdf -File -ErrorAction SilentlyContinue)
        $candidates = @()
        foreach ($f in $files) {
            $np = Get-PeriodFromName $f.Name
            if ($np -and $np.Key -ne $latest.Key) { continue }
            if (-not $np) {
                # Unknown filename: only consider a few newest files.
                $rank = @($files | Sort-Object LastWriteTime -Descending | Select-Object -First 4).FullName
                if ($rank -notcontains $f.FullName) { continue }
            }

            try {
                $text = Get-PdfTextDirect $f.FullName
                if ([string]::IsNullOrWhiteSpace($text)) {
                    $blankTextCount++
                    $errors += "$account — PDF открыт, но текст пустой: $($f.Name)"
                    continue
                }
                $tp = Get-PeriodFromText $text
                if ($tp -and $tp.Key -ne $latest.Key) { continue }
                $type = Get-ReceiptType $text
                $apt = Get-Apartment $text

                # Organize and rename the original PDF immediately after its type/apartment are known.
                $periodForFile = if ($tp) { $tp } elseif ($np) { $np } else { $latest }
                $organizedPath = Move-ReceiptToTypeFolder `
                    -AccountFolder ([string]$folder.FullName) `
                    -Account $account `
                    -Apartment $apt `
                    -Type $type `
                    -Year ([int]$periodForFile.Year) `
                    -Month ([int]$periodForFile.Month) `
                    -FilePath ([string]$f.FullName)

                $organizedFile = Get-Item -LiteralPath $organizedPath -ErrorAction SilentlyContinue
                if (-not $organizedFile) { $organizedFile = $f }

                $candidates += [pscustomobject]@{File=$organizedFile;Type=$type;Apartment=$apt}
            }
            catch {
                $readErrorCount++
                $errors += "$account — не прочитан $($f.Name): $($_.Exception.Message)"
            }
        }

        $capCount += @($candidates | Where-Object {$_.Type -eq 'Капремонт'} | Select-Object -First 1).Count
        $unknownCount += @($candidates | Where-Object {$_.Type -eq 'Не определено'}).Count
        $jkh = @($candidates | Where-Object {$_.Type -eq 'ЖКХ'} | Sort-Object {$_.File.LastWriteTime} -Descending | Select-Object -First 1)
        $currentFolderPath = [string]$folder.FullName
        if ($jkh.Count -eq 1) {
            $x = $jkh[0]

            # Make receipt folders understandable in Explorer:
            # "02020612901 - кв. 129Е" instead of only the personal account number.
            $apartment = ([string]$x.Apartment).Trim()

            if (-not [string]::IsNullOrWhiteSpace($apartment)) {
                $safeApartment = $apartment
                foreach ($bad in [IO.Path]::GetInvalidFileNameChars()) {
                    $safeApartment = $safeApartment.Replace([string]$bad, '_')
                }

                $desiredName = $account + ' - кв. ' + $safeApartment
                $desiredPath = Join-Path $ReceiptsDir $desiredName

                if ($folder.Name -ne $desiredName) {
                    try {
                        if (-not (Test-Path -LiteralPath $desiredPath)) {
                            Rename-Item -LiteralPath $folder.FullName -NewName $desiredName -ErrorAction Stop
                            $currentFolderPath = $desiredPath
                        }
                        else {
                            # If a correctly named folder already exists, keep using it.
                            $currentFolderPath = $desiredPath
                        }
                    }
                    catch {
                        # Folder naming is a convenience only; scanning must still succeed.
                        $currentFolderPath = [string]$folder.FullName
                    }
                }
                else {
                    $currentFolderPath = [string]$folder.FullName
                }
            }

            # The parent folder may just have been renamed, so x.File.FullName can be stale.
            # Resolve the real PDF recursively inside the current account folder.
            $resolvedPdf = @(
                Get-ChildItem -LiteralPath $currentFolderPath -Recurse -Filter $x.File.Name -File -ErrorAction SilentlyContinue |
                Select-Object -First 1
            )

            if ($resolvedPdf.Count -eq 0) {
                # Fallback: locate the latest ЖКХ PDF by the readable filename pattern.
                $resolvedPdf = @(
                    Get-ChildItem -LiteralPath $currentFolderPath -Recurse -Filter *.pdf -File -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -match '_ЖКХ_' } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1
                )
            }

            if ($resolvedPdf.Count -eq 0) {
                throw "Не найден фактический файл ЖКХ после сортировки: $currentFolderPath"
            }

            $realPdf = $resolvedPdf[0]

            $items += [pscustomobject]@{
                Account=$account
                Apartment=$x.Apartment
                Period=("{0:D2}.{1}" -f $latest.Month,$latest.Year)
                PdfPath=$realPdf.FullName
                PdfName=$realPdf.Name
                Type='ЖКХ'
            }
        } else {
            $unknown = @($candidates | Where-Object {$_.Type -eq 'Не определено'}).Count
            $caps = @($candidates | Where-Object {$_.Type -eq 'Капремонт'}).Count
            $errors += "$account — ЖКХ за последний месяц не найдено (капремонт: $caps, не определено: $unknown)"
        }

        # Keep one latest capital-repair receipt per account for the selected month.
        $cap = @($candidates | Where-Object {$_.Type -eq 'Капремонт'} | Sort-Object {$_.File.LastWriteTime} -Descending | Select-Object -First 1)
        if ($cap.Count -eq 1) {
            $c = $cap[0]
            $capApartment = ([string]$c.Apartment).Trim()
            if ([string]::IsNullOrWhiteSpace($capApartment) -and $jkh.Count -eq 1) {
                $capApartment = ([string]$jkh[0].Apartment).Trim()
            }

            $resolvedCap = @(
                Get-ChildItem -LiteralPath $currentFolderPath -Recurse -Filter $c.File.Name -File -ErrorAction SilentlyContinue |
                Select-Object -First 1
            )
            if ($resolvedCap.Count -eq 0) {
                $resolvedCap = @(
                    Get-ChildItem -LiteralPath $currentFolderPath -Recurse -Filter *.pdf -File -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -match '_Капремонт_' } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1
                )
            }

            if ($resolvedCap.Count -gt 0) {
                $realCap = $resolvedCap[0]
                $capItems += [pscustomobject]@{
                    Account=$account
                    Apartment=$capApartment
                    Period=("{0:D2}.{1}" -f $latest.Month,$latest.Year)
                    PdfPath=$realCap.FullName
                    PdfName=$realCap.Name
                    Type='Капремонт'
                }
            }
        }
    }

    $result = [pscustomobject]@{
        Period=("{0:D2}.{1}" -f $latest.Month,$latest.Year)
        AccountsCount=$folders.Count
        JkhCount=$items.Count
        CapCount=$capItems.Count
        UnknownCount=$unknownCount
        ReadErrorCount=$readErrorCount
        BlankTextCount=$blankTextCount
        Items=$items
        CapItems=$capItems
        AllItems=@($items + $capItems)
        Errors=$errors
        Engine='Poppler pdftotext direct PDF text extraction'
    }
    $result | ConvertTo-Json -Depth 8 | Set-Content $ResultFile -Encoding UTF8
    exit 0
}
catch {
    ($_ | Out-String) | Set-Content $ErrorFile -Encoding UTF8
    exit 2
}
