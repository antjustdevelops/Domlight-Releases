﻿
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = "Stop"

trap {
    [System.Windows.Forms.MessageBox]::Show(
        "Ошибка окна подключения:`r`n$($_.Exception.Message)",
        "Domlight",
        "OK",
        "Error"
    ) | Out-Null
    break
}

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir = Join-Path $Root "data"
$ConfigFile = Join-Path $DataDir "connection.json"
$IconFile = Join-Path $Root "Domlight.ico"
$TestUrl = "https://lk.kakdoma.life/login"
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null

$config = [pscustomobject]@{
    useProxy = $false
    proxyUrl = ""
    proxyUser = ""
    proxyPassword = ""
}
if (Test-Path $ConfigFile) {
    try {
        $saved = Get-Content $ConfigFile -Raw | ConvertFrom-Json
        $config.useProxy = [bool]$saved.useProxy
        $config.proxyUrl = [string]$saved.proxyUrl
        $config.proxyUser = [string]$saved.proxyUser
        $config.proxyPassword = [string]$saved.proxyPassword
    } catch {}
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "Domlight — настройка подключения"
$form.Size = New-Object Drawing.Size(650, 590)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.BackColor = [Drawing.Color]::FromArgb(245,247,250)
$form.Font = New-Object Drawing.Font("Segoe UI", 10)
if (Test-Path $IconFile) { try { $form.Icon = New-Object Drawing.Icon($IconFile) } catch {} }

$title = New-Object System.Windows.Forms.Label
$title.Text = "Подключение к Домлайту"
$title.Font = New-Object Drawing.Font("Segoe UI", 19, [Drawing.FontStyle]::Bold)
$title.Location = New-Object Drawing.Point(28, 20)
$title.AutoSize = $true
$form.Controls.Add($title)

$desc = New-Object System.Windows.Forms.Label
$desc.Text = "В России оставьте «Напрямую». За границей можно включить российский прокси.`r`nПроверка покажет, доступен ли Домлайт с выбранными настройками."
$desc.Location = New-Object Drawing.Point(30, 62)
$desc.Size = New-Object Drawing.Size(575, 50)
$desc.ForeColor = [Drawing.Color]::DimGray
$form.Controls.Add($desc)

$groupMode = New-Object System.Windows.Forms.GroupBox
$groupMode.Text = "1. Режим подключения"
$groupMode.Location = New-Object Drawing.Point(30, 120)
$groupMode.Size = New-Object Drawing.Size(575, 85)
$form.Controls.Add($groupMode)

$rbDirect = New-Object System.Windows.Forms.RadioButton
$rbDirect.Text = "Напрямую — обычное подключение"
$rbDirect.Location = New-Object Drawing.Point(18, 28)
$rbDirect.Size = New-Object Drawing.Size(285, 28)
$rbDirect.Checked = -not $config.useProxy
$groupMode.Controls.Add($rbDirect)

$rbProxy = New-Object System.Windows.Forms.RadioButton
$rbProxy.Text = "Через российский прокси"
$rbProxy.Location = New-Object Drawing.Point(315, 28)
$rbProxy.Size = New-Object Drawing.Size(235, 28)
$rbProxy.Checked = $config.useProxy
$groupMode.Controls.Add($rbProxy)

$groupProxy = New-Object System.Windows.Forms.GroupBox
$groupProxy.Text = "2. Данные российского прокси"
$groupProxy.Location = New-Object Drawing.Point(30, 215)
$groupProxy.Size = New-Object Drawing.Size(575, 205)
$form.Controls.Add($groupProxy)

function Add-Field([string]$Caption, [int]$Y, [string]$Value, [bool]$Password = $false) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Caption
    $label.Location = New-Object Drawing.Point(18, $Y)
    $label.Size = New-Object Drawing.Size(145, 26)
    $groupProxy.Controls.Add($label)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Location = New-Object Drawing.Point(170, ($Y - 2))
    $box.Size = New-Object Drawing.Size(370, 28)
    $box.Text = $Value
    if ($Password) { $box.UseSystemPasswordChar = $true }
    $groupProxy.Controls.Add($box)
    return $box
}

$txtProxy = Add-Field "IP / адрес и порт:" 30 $config.proxyUrl
$txtLogin = Add-Field "Логин:" 78 $config.proxyUser
$txtPassword = Add-Field "Пароль:" 126 $config.proxyPassword $true

$example = New-Object System.Windows.Forms.Label
$example.Text = "Пример: http://185.123.45.67:8080"
$example.Location = New-Object Drawing.Point(170, 165)
$example.Size = New-Object Drawing.Size(350, 24)
$example.ForeColor = [Drawing.Color]::Gray
$groupProxy.Controls.Add($example)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object Drawing.Point(30, 432)
$statusPanel.Size = New-Object Drawing.Size(575, 55)
$statusPanel.BackColor = [Drawing.Color]::White
$statusPanel.BorderStyle = "FixedSingle"
$form.Controls.Add($statusPanel)

$status = New-Object System.Windows.Forms.Label
$status.Text = "Соединение ещё не проверялось."
$status.Location = New-Object Drawing.Point(15, 15)
$status.Size = New-Object Drawing.Size(540, 26)
$status.ForeColor = [Drawing.Color]::DimGray
$statusPanel.Controls.Add($status)

function Update-ProxyFields {
    $enabled = $rbProxy.Checked
    $txtProxy.Enabled = $enabled
    $txtLogin.Enabled = $enabled
    $txtPassword.Enabled = $enabled
}
$rbDirect.Add_CheckedChanged({ Update-ProxyFields })
$rbProxy.Add_CheckedChanged({ Update-ProxyFields })
Update-ProxyFields

$btnTest = New-Object System.Windows.Forms.Button
$btnTest.Text = "Проверить соединение"
$btnTest.Location = New-Object Drawing.Point(30, 505)
$btnTest.Size = New-Object Drawing.Size(190, 40)
$btnTest.FlatStyle = "Flat"
$btnTest.FlatAppearance.BorderSize = 0
$btnTest.BackColor = [Drawing.Color]::FromArgb(22,163,74)
$btnTest.ForeColor = [Drawing.Color]::White
$btnTest.Add_Click({
    $btnTest.Enabled = $false
    $status.Text = "Проверяю доступ к Домлайту..."
    $status.ForeColor = [Drawing.Color]::DarkOrange
    [System.Windows.Forms.Application]::DoEvents()

    try {
        $args = @{
            Uri = $TestUrl
            Method = "GET"
            UseBasicParsing = $true
            TimeoutSec = 20
            Headers = @{
                "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0"
            }
        }

        if ($rbProxy.Checked) {
            if ([string]::IsNullOrWhiteSpace($txtProxy.Text)) {
                throw "Введите IP/адрес и порт прокси."
            }
            $args["Proxy"] = $txtProxy.Text.Trim()
            $args["ProxyUseDefaultCredentials"] = $false

            if (-not [string]::IsNullOrWhiteSpace($txtLogin.Text)) {
                $sec = ConvertTo-SecureString $txtPassword.Text -AsPlainText -Force
                $cred = New-Object System.Management.Automation.PSCredential ($txtLogin.Text.Trim(), $sec)
                $args["ProxyCredential"] = $cred
            }
        }

        $r = Invoke-WebRequest @args
        if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 400) {
            if ($rbProxy.Checked) {
                $status.Text = "✓ Домлайт доступен через указанный прокси."
            } else {
                $status.Text = "✓ Домлайт доступен напрямую."
            }
            $status.ForeColor = [Drawing.Color]::Green
        } else {
            throw "Домлайт ответил HTTP $($r.StatusCode)."
        }
    }
    catch {
        $status.Text = "✖ Нет доступа: $($_.Exception.Message)"
        $status.ForeColor = [Drawing.Color]::DarkRed
    }
    finally {
        $btnTest.Enabled = $true
    }
})
$form.Controls.Add($btnTest)

$btnSave = New-Object System.Windows.Forms.Button
$btnSave.Text = "Сохранить"
$btnSave.Location = New-Object Drawing.Point(305, 505)
$btnSave.Size = New-Object Drawing.Size(140, 40)
$btnSave.FlatStyle = "Flat"
$btnSave.FlatAppearance.BorderSize = 0
$btnSave.BackColor = [Drawing.Color]::FromArgb(37,99,235)
$btnSave.ForeColor = [Drawing.Color]::White
$btnSave.Add_Click({
    $obj = [pscustomobject]@{
        useProxy = $rbProxy.Checked
        proxyUrl = $txtProxy.Text.Trim()
        proxyUser = $txtLogin.Text.Trim()
        proxyPassword = $txtPassword.Text
    }
    $obj | ConvertTo-Json | Set-Content -Path $ConfigFile -Encoding UTF8
    [System.Windows.Forms.MessageBox]::Show(
        "Настройки подключения сохранены.",
        "Domlight",
        "OK",
        "Information"
    ) | Out-Null
    $form.Close()
})
$form.Controls.Add($btnSave)

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = "Отмена"
$btnCancel.Location = New-Object Drawing.Point(465, 505)
$btnCancel.Size = New-Object Drawing.Size(140, 40)
$btnCancel.Add_Click({ $form.Close() })
$form.Controls.Add($btnCancel)

[void]$form.ShowDialog()
