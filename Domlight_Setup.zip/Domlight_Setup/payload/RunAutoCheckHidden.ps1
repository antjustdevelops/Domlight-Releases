﻿
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir = Join-Path $Root "data"
$Flag = Join-Path $DataDir "check_done.flag"
$Auto = Join-Path $Root "AutoCheck.ps1"

New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
try {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File $Auto
} finally {
    (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") | Set-Content -Path $Flag -Encoding ASCII
}
