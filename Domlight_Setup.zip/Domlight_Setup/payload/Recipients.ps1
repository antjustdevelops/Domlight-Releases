﻿param([string]$ScanFile)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir = Join-Path $Root 'data'
$File = Join-Path $DataDir 'recipients.json'
$IconFile = Join-Path $Root 'Domlight.ico'

$scan = $null
if ($ScanFile -and (Test-Path $ScanFile)) { try { $scan = Get-Content $ScanFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch {} }
$map = @{}
if (Test-Path $File) { try { foreach($r in @(Get-Content $File -Raw -Encoding UTF8 | ConvertFrom-Json)) { $map[[string]$r.Account]=$r } } catch {} }

$form=New-Object Windows.Forms.Form
$form.Text='Domlight — Получатели'
$form.Size=New-Object Drawing.Size(850,430)
$form.StartPosition='CenterParent'
$form.Font=New-Object Drawing.Font('Segoe UI',10)
if(Test-Path $IconFile){try{$form.Icon=New-Object Drawing.Icon($IconFile)}catch{}}

$lbl=New-Object Windows.Forms.Label
$lbl.Text='Получатели по квартирам'
$lbl.Font=New-Object Drawing.Font('Segoe UI',17,[Drawing.FontStyle]::Bold)
$lbl.Location=New-Object Drawing.Point(20,16);$lbl.AutoSize=$true;$form.Controls.Add($lbl)
$hint=New-Object Windows.Forms.Label
$hint.Text='Заполняется один раз. Лицевой счёт используется только как внутренняя связь с квартирой.'
$hint.Location=New-Object Drawing.Point(23,52);$hint.Size=New-Object Drawing.Size(790,25);$form.Controls.Add($hint)

$grid=New-Object Windows.Forms.DataGridView
$grid.Location=New-Object Drawing.Point(23,85);$grid.Size=New-Object Drawing.Size(790,245)
$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false;$grid.AutoSizeColumnsMode='Fill';$grid.BackgroundColor=[Drawing.Color]::White
$form.Controls.Add($grid)
$dt=New-Object Data.DataTable
foreach($c in @('Лицевой счёт','Квартира','Имя','E-mail','WhatsApp')){[void]$dt.Columns.Add($c)}
foreach($i in @($scan.Items)){
    $dr=$dt.NewRow();$dr['Лицевой счёт']=[string]$i.Account;$dr['Квартира']=[string]$i.Apartment
    if($map.ContainsKey([string]$i.Account)){$r=$map[[string]$i.Account];$dr['Имя']=[string]$r.Recipient;$dr['E-mail']=[string]$r.Email;$dr['WhatsApp']=[string]$r.WhatsApp}
    $dt.Rows.Add($dr)
}
$grid.DataSource=$dt
$grid.Columns['Лицевой счёт'].Visible=$false
$grid.Columns['Квартира'].ReadOnly=$true

$save=New-Object Windows.Forms.Button
$save.Text='Сохранить';$save.Location=New-Object Drawing.Point(613,342);$save.Size=New-Object Drawing.Size(200,42);$save.BackColor=[Drawing.Color]::FromArgb(37,99,235);$save.ForeColor=[Drawing.Color]::White;$save.FlatStyle='Flat';$save.FlatAppearance.BorderSize=0
$save.Add_Click({
    $out=@();foreach($row in $dt.Rows){$out += [pscustomobject]@{Account=[string]$row['Лицевой счёт'];Apartment=[string]$row['Квартира'];Recipient=[string]$row['Имя'];Email=[string]$row['E-mail'];WhatsApp=[string]$row['WhatsApp']}}
    $out|ConvertTo-Json -Depth 4|Set-Content $File -Encoding UTF8
    $form.DialogResult=[Windows.Forms.DialogResult]::OK;$form.Close()
});$form.Controls.Add($save)
[void]$form.ShowDialog()
