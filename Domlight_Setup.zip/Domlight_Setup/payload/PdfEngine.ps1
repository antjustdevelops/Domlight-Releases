﻿
param([switch]$InstallOnly)
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$EngineRoot = Join-Path $Root "lib\pdfengine"
$Pdftotext = Join-Path $EngineRoot "pdftotext.exe"
$VersionFile = Join-Path $EngineRoot "engine.version"
$EngineVersion = "poppler-pdftotext-v1"

function Install-DomlightPdfEngine {
    $ready = (Test-Path $Pdftotext) -and (Test-Path $VersionFile)
    if ($ready) {
        $v = (Get-Content $VersionFile -Raw -ErrorAction SilentlyContinue).Trim()
        if ($v -eq $EngineVersion) { return }
    }

    if (Test-Path $EngineRoot) {
        Remove-Item $EngineRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Force -Path $EngineRoot | Out-Null

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $headers = @{
        "User-Agent" = "Domlight-Updater"
        "Accept" = "application/vnd.github+json"
    }

    $release = Invoke-RestMethod `
        -Uri "https://api.github.com/repos/oschwartz10612/poppler-windows/releases/latest" `
        -Headers $headers `
        -UseBasicParsing `
        -TimeoutSec 90

    $asset = @($release.assets | Where-Object {
        $_.name -match '^Release-.*\.zip$'
    } | Select-Object -First 1)

    if ($asset.Count -eq 0) {
        throw "Не найден ZIP-архив Poppler в последнем релизе."
    }

    $zip = Join-Path $env:TEMP ("domlight_poppler_" + [guid]::NewGuid().ToString("N") + ".zip")
    $tmp = Join-Path $env:TEMP ("domlight_poppler_" + [guid]::NewGuid().ToString("N"))

    try {
        Invoke-WebRequest `
            -Uri $asset[0].browser_download_url `
            -Headers $headers `
            -OutFile $zip `
            -UseBasicParsing `
            -TimeoutSec 180

        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::ExtractToDirectory($zip, $tmp)

        $srcExe = Get-ChildItem $tmp -Recurse -Filter "pdftotext.exe" -File |
            Select-Object -First 1

        if (-not $srcExe) {
            throw "В скачанном Poppler не найден pdftotext.exe."
        }

        $binDir = $srcExe.Directory.FullName

        # Copy the executable and all DLLs beside it so it is self-contained.
        Copy-Item $srcExe.FullName $Pdftotext -Force
        Get-ChildItem $binDir -Filter "*.dll" -File -ErrorAction SilentlyContinue | ForEach-Object {
            Copy-Item $_.FullName (Join-Path $EngineRoot $_.Name) -Force
        }

        if (-not (Test-Path $Pdftotext)) {
            throw "pdftotext.exe не установлен."
        }

        Set-Content -Path $VersionFile -Value $EngineVersion -Encoding ASCII
    }
    finally {
        Remove-Item $zip -Force -ErrorAction SilentlyContinue
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Get-PdfTextDirect {
    param([Parameter(Mandatory=$true)][string]$Path)

    Install-DomlightPdfEngine

    if (-not (Test-Path $Path)) {
        throw "PDF-файл не найден: $Path"
    }

    $out = Join-Path $env:TEMP ("domlight_pdftext_" + [guid]::NewGuid().ToString("N") + ".txt")

    try {
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = $Pdftotext
        $psi.Arguments = '-enc UTF-8 -layout "' + $Path.Replace('"','""') + '" "' + $out + '"'
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardError = $true
        $psi.RedirectStandardOutput = $true

        $p = [Diagnostics.Process]::Start($psi)

        if (-not $p.WaitForExit(20000)) {
            try { $p.Kill() } catch {}
            throw "Чтение PDF превысило 20 секунд."
        }

        $stderr = $p.StandardError.ReadToEnd()

        if ($p.ExitCode -ne 0) {
            throw "pdftotext завершился с кодом $($p.ExitCode): $stderr"
        }

        if (-not (Test-Path $out)) {
            throw "pdftotext не создал текстовый результат."
        }

        $text = Get-Content $out -Raw -Encoding UTF8

        if ([string]::IsNullOrWhiteSpace($text)) {
            throw "PDF прочитан, но текст в нём не найден."
        }

        return $text
    }
    finally {
        Remove-Item $out -Force -ErrorAction SilentlyContinue
    }
}

if ($InstallOnly) {
    Install-DomlightPdfEngine
}
