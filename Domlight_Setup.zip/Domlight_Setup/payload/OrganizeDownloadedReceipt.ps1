﻿param(
    [Parameter(Mandatory=$true)][string]$ReceiptsDir,
    [Parameter(Mandatory=$true)][string]$Account,
    [Parameter(Mandatory=$true)][string]$FilePath
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $Root "PdfEngine.ps1")

function Safe-Part([string]$Text) {
    $v = ([string]$Text).Trim()
    foreach ($c in [IO.Path]::GetInvalidFileNameChars()) {
        $v = $v.Replace([string]$c, '_')
    }
    return $v
}

function Normalize-ReceiptText([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) {
        return [pscustomobject]@{ Normal=''; Compact='' }
    }
    $normal = ($Text -replace '[\u0000-\u001F]+',' ' -replace '\s+',' ').Trim().ToLowerInvariant()
    $compact = ($normal -replace '[^0-9a-zа-яё]+','')
    return [pscustomobject]@{ Normal=$normal; Compact=$compact }
}

function Get-Apartment([string]$Text) {
    $n = Normalize-ReceiptText $Text
    $normal = $n.Normal
    $compact = $n.Compact

    $patterns = @(
        '(?i)\bадрес\s*:\s*.*?\bапарт\.?\s*([0-9]+[0-9a-zа-яё-]*)',
        '(?i)\bапарт\.?\s*([0-9]+[0-9a-zа-яё-]*)',
        '(?i)\bапартамент(?:а|ов)?\s*([0-9]+[0-9a-zа-яё-]*)',
        '(?i)\bкв(?:артира)?\.?\s*([0-9]+[0-9a-zа-яё-]*)'
    )
    foreach ($pattern in $patterns) {
        $m = [regex]::Match($normal, $pattern)
        if ($m.Success) { return $m.Groups[1].Value.ToUpperInvariant() }
    }

    foreach ($pattern in @(
        'апарт(?:амент(?:а|ов)?)?([0-9]+[0-9a-zа-яё-]*)',
        'квартира([0-9]+[0-9a-zа-яё-]*)'
    )) {
        $m = [regex]::Match($compact, $pattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($m.Success) { return $m.Groups[1].Value.ToUpperInvariant() }
    }
    return ''
}

function Get-TypeFromName([string]$Name) {
    $m = [regex]::Match($Name, '^20\d{2}[_-](?:0[1-9]|1[0-2])[_-](?<kind>[12])[_-]')
    if ($m.Success) {
        if ($m.Groups['kind'].Value -eq '1') { return 'ЖКХ' }
        if ($m.Groups['kind'].Value -eq '2') { return 'Капремонт' }
    }
    return ''
}

function Get-TypeFromText([string]$Text) {
    $n = Normalize-ReceiptText $Text
    $normal = $n.Normal
    $compact = $n.Compact

    if (($compact -match 'капитальн') -and ($compact -match 'ремонт')) {
        return 'Капремонт'
    }

    $signals = 0
    foreach ($s in @('коммунальн','электроснабж','водоснабж','водоотвед','содержание','консьерж')) {
        if ($compact -match $s) { $signals++ }
    }
    if ($signals -ge 2 -or $normal -match 'предоставлен\w*\s+коммунальн\w*\s+услуг') {
        return 'ЖКХ'
    }
    return ''
}

function Get-Period([string]$Name, [string]$Text) {
    $m = [regex]::Match($Name, '^(?<y>20\d{2})[_-](?<m>0[1-9]|1[0-2])[_-]')
    if ($m.Success) {
        return [pscustomobject]@{ Year=[int]$m.Groups['y'].Value; Month=[int]$m.Groups['m'].Value }
    }

    $months = @{
        "январ"=1; "феврал"=2; "март"=3; "апрел"=4; "май"=5; "мая"=5; "июн"=6;
        "июл"=7; "август"=8; "сентябр"=9; "октябр"=10; "ноябр"=11; "декабр"=12
    }
    $n = Normalize-ReceiptText $Text
    $m = [regex]::Match($n.Normal, '(?i)\bза\s+(?<month>январ\w*|феврал\w*|март\w*|апрел\w*|ма[йя]|июн\w*|июл\w*|август\w*|сентябр\w*|октябр\w*|ноябр\w*|декабр\w*)\s+(?<year>20\d{2})')
    if ($m.Success) {
        $word = $m.Groups['month'].Value.ToLowerInvariant()
        foreach ($k in $months.Keys) {
            if ($word.StartsWith($k)) {
                return [pscustomobject]@{ Year=[int]$m.Groups['year'].Value; Month=[int]$months[$k] }
            }
        }
    }
    return $null
}

if (-not (Test-Path -LiteralPath $FilePath)) { exit 0 }

$text = Get-PdfTextDirect $FilePath
$apt = Get-Apartment $text
$type = Get-TypeFromName ([IO.Path]::GetFileName($FilePath))
if ([string]::IsNullOrWhiteSpace($type)) { $type = Get-TypeFromText $text }
$period = Get-Period ([IO.Path]::GetFileName($FilePath)) $text

if ([string]::IsNullOrWhiteSpace($apt) -or
    [string]::IsNullOrWhiteSpace($type) -or
    -not $period) {
    # Leave the original untouched rather than guessing.
    exit 0
}

$safeApt = Safe-Part $apt
$safeAccount = Safe-Part $Account

$accountFolder = Join-Path $ReceiptsDir ($safeAccount + ' - кв. ' + $safeApt)
$typeFolder = Join-Path $accountFolder ($type + ' - ЛС ' + $safeAccount + ' - кв. ' + $safeApt)

New-Item -ItemType Directory -Force -Path $typeFolder | Out-Null

$newName = ('{0:D4}_{1:D2}_{2}_кв_{3}_ЛС_{4}.pdf' -f $period.Year,$period.Month,$type,$safeApt,$safeAccount)
$dest = Join-Path $typeFolder $newName

if (Test-Path -LiteralPath $dest) {
    # Keep both only if truly different.
    try {
        $a = (Get-FileHash -LiteralPath $FilePath -Algorithm SHA256).Hash
        $b = (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash
        if ($a -eq $b) {
            Remove-Item -LiteralPath $FilePath -Force -ErrorAction SilentlyContinue
            exit 0
        }
    } catch {}

    $base = [IO.Path]::GetFileNameWithoutExtension($dest)
    $ext = [IO.Path]::GetExtension($dest)
    $dir = Split-Path -Parent $dest
    $i = 2
    do {
        $candidate = Join-Path $dir ($base + '_' + $i + $ext)
        $i++
    } while (Test-Path -LiteralPath $candidate)
    $dest = $candidate
}

Move-Item -LiteralPath $FilePath -Destination $dest -Force

# Remove the temporary numeric account folder if it became empty.
$oldFolder = Join-Path $ReceiptsDir $Account
if (Test-Path -LiteralPath $oldFolder) {
    try {
        if (@(Get-ChildItem -LiteralPath $oldFolder -Force).Count -eq 0) {
            Remove-Item -LiteralPath $oldFolder -Force
        }
    } catch {}
}
