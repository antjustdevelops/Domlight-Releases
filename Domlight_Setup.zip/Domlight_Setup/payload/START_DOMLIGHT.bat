@echo off
wscript.exe "%~dp0OpenDomlight.vbs"
exit /b
