@echo off
cd /d "%~dp0"
if not exist "data\DOMLIGHT_REPORT.txt" echo Report not created yet.>"data\DOMLIGHT_REPORT.txt"
start notepad.exe "data\DOMLIGHT_REPORT.txt"
