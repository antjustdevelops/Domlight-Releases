﻿Add-Type -AssemblyName System.Web
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Security

$script:GmailScope = 'https://www.googleapis.com/auth/gmail.send'
$script:GmailFromName = 'ABRENTALS'
$script:GmailFromAddress = 'abrentals@ahb.global'

function Protect-GmailText {
    param([string]$Text)
    $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
    $protected = [System.Security.Cryptography.ProtectedData]::Protect(
        $bytes,
        $null,
        [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    return [Convert]::ToBase64String($protected)
}

function Unprotect-GmailText {
    param([string]$Text)
    $bytes = [Convert]::FromBase64String($Text)
    $plain = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $bytes,
        $null,
        [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    return [Text.Encoding]::UTF8.GetString($plain)
}

function Read-GmailOAuthFile {
    param([string]$Path)

    try {
        $json = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
        $cfg = if ($json.installed) { $json.installed } elseif ($json.web) { $json.web } else { $null }
        if (-not $cfg -or -not $cfg.client_id) { return $null }

        return [pscustomobject]@{
            Path = $Path
            ClientId = [string]$cfg.client_id
            ClientSecret = [string]$cfg.client_secret
            AuthUri = if ($cfg.auth_uri) { [string]$cfg.auth_uri } else { 'https://accounts.google.com/o/oauth2/v2/auth' }
            TokenUri = if ($cfg.token_uri) { [string]$cfg.token_uri } else { 'https://oauth2.googleapis.com/token' }
        }
    }
    catch {
        return $null
    }
}

function Find-GmailOAuthDownload {
    $downloadFolders = @()

    try {
        $downloadFolders += (Join-Path $env:USERPROFILE 'Downloads')
    } catch {}

    try {
        $shell = New-Object -ComObject Shell.Application
        $known = $shell.Namespace('shell:Downloads')
        if ($known -and $known.Self.Path) {
            $downloadFolders += [string]$known.Self.Path
        }
    } catch {}

    $downloadFolders = @($downloadFolders | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique)

    $candidates = @()
    foreach ($folder in $downloadFolders) {
        $candidates += Get-ChildItem -LiteralPath $folder -Filter '*.json' -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
    }

    foreach ($file in @($candidates | Sort-Object LastWriteTime -Descending)) {
        $cfg = Read-GmailOAuthFile $file.FullName
        if ($cfg) {
            return $file.FullName
        }
    }

    return $null
}

function Get-GmailConfig {
    param([string]$Root)

    $dataDir = Join-Path $Root 'data'
    New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
    $dest = Join-Path $dataDir 'gmail_client_secret.json'

    if (Test-Path $dest) {
        $cfg = Read-GmailOAuthFile $dest
        if ($cfg) { return $cfg }
    }

    $auto = Find-GmailOAuthDownload
    if ($auto) {
        Copy-Item -LiteralPath $auto -Destination $dest -Force
        $cfg = Read-GmailOAuthFile $dest
        if ($cfg) {
            [Windows.Forms.MessageBox]::Show(
                "Domlight нашёл скачанный Google OAuth-файл и подключил его автоматически.`r`n`r`n" +
                "Сейчас откроется Google для одноразового разрешения отправки почты.",
                'Gmail',
                'OK',
                'Information'
            ) | Out-Null
            return $cfg
        }
    }

    $dialog = New-Object Windows.Forms.OpenFileDialog
    $dialog.Title = 'Выберите скачанный JSON Google OAuth'
    $dialog.Filter = 'JSON (*.json)|*.json|Все файлы (*.*)|*.*'
    $dialog.Multiselect = $false

    if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) {
        throw 'OAuth JSON не найден. Выберите скачанный файл Google.'
    }

    $cfg = Read-GmailOAuthFile ([string]$dialog.FileName)
    if (-not $cfg) {
        throw 'Выбранный JSON не похож на OAuth Client ID Google.'
    }

    Copy-Item -LiteralPath ([string]$dialog.FileName) -Destination $dest -Force
    return (Read-GmailOAuthFile $dest)
}

function Save-GmailToken {
    param([string]$DataDir, $Token)

    $path = Join-Path $DataDir 'gmail_token.dat'
    $obj = [pscustomobject]@{
        access_token = [string]$Token.access_token
        refresh_token = [string]$Token.refresh_token
        expires_at = if ($Token.expires_in) {
            (Get-Date).AddSeconds([int]$Token.expires_in - 60).ToString('o')
        } else {
            (Get-Date).AddMinutes(50).ToString('o')
        }
    }

    $json = $obj | ConvertTo-Json -Compress
    Set-Content -LiteralPath $path -Value (Protect-GmailText $json) -Encoding ASCII
}

function Load-GmailToken {
    param([string]$DataDir)

    $path = Join-Path $DataDir 'gmail_token.dat'
    if (-not (Test-Path $path)) { return $null }

    try {
        $protected = Get-Content -LiteralPath $path -Raw -Encoding ASCII
        $json = Unprotect-GmailText $protected.Trim()
        return $json | ConvertFrom-Json
    }
    catch {
        return $null
    }
}

function Get-FreeTcpPort {
    $listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $port = ([Net.IPEndPoint]$listener.LocalEndpoint).Port
    $listener.Stop()
    return $port
}

function Invoke-GmailAuthorization {
    param([string]$Root, [string]$DataDir)

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $cfg = Get-GmailConfig $Root

    # Use a raw TCP listener instead of HttpListener.
    # HttpListener can hang on some Windows installations because of URL ACL /
    # local callback registration behavior.
    $tcp = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, 0)
    $tcp.Start()
    $port = ([Net.IPEndPoint]$tcp.LocalEndpoint).Port
    $redirect = "http://127.0.0.1:$port/"

    try {
        $authUrl = $cfg.AuthUri +
            '?client_id=' + [Web.HttpUtility]::UrlEncode($cfg.ClientId) +
            '&redirect_uri=' + [Web.HttpUtility]::UrlEncode($redirect) +
            '&response_type=code' +
            '&scope=' + [Web.HttpUtility]::UrlEncode($script:GmailScope) +
            '&access_type=offline' +
            '&prompt=consent'

        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = $authUrl
        $psi.UseShellExecute = $true
        [void][Diagnostics.Process]::Start($psi)

        [Windows.Forms.MessageBox]::Show(
            "Google откроется один раз.`r`n`r`n" +
            "Выберите нужный аккаунт и нажмите «Allow / Разрешить».`r`n" +
            "После нажатия браузер должен автоматически вернуться в Domlight.",
            'Gmail — первое подключение',
            'OK',
            'Information'
        ) | Out-Null

        $tcp.Server.ReceiveTimeout = 120000
        $client = $tcp.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::ASCII, $false, 4096, $true)

            $requestLine = $reader.ReadLine()
            if ([string]::IsNullOrWhiteSpace($requestLine)) {
                throw 'Не получен ответ от Google.'
            }

            # Consume the remaining HTTP request headers.
            while ($true) {
                $line = $reader.ReadLine()
                if ($null -eq $line -or $line -eq '') { break }
            }

            $parts = $requestLine.Split(' ')
            if ($parts.Count -lt 2) {
                throw 'Некорректный ответ браузера.'
            }

            $target = [string]$parts[1]
            $uri = New-Object Uri("http://127.0.0.1:$port$target")
            $query = [Web.HttpUtility]::ParseQueryString($uri.Query)
            $code = [string]$query['code']
            $error = [string]$query['error']

            $html = if ($code) {
                '<html><body style="font-family:Segoe UI"><h2>Готово</h2><p>Gmail подключён к Domlight. Это окно можно закрыть.</p></body></html>'
            } else {
                '<html><body style="font-family:Segoe UI"><h2>Подключение не завершено</h2><p>Вернитесь в Domlight.</p></body></html>'
            }

            $bodyBytes = [Text.Encoding]::UTF8.GetBytes($html)
            $header = "HTTP/1.1 200 OK`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($bodyBytes.Length)`r`nConnection: close`r`n`r`n"
            $headerBytes = [Text.Encoding]::ASCII.GetBytes($header)

            $stream.Write($headerBytes, 0, $headerBytes.Length)
            $stream.Write($bodyBytes, 0, $bodyBytes.Length)
            $stream.Flush()

            if ($error) {
                throw "Google вернул ошибку: $error"
            }
            if ([string]::IsNullOrWhiteSpace($code)) {
                throw 'Google не вернул код авторизации.'
            }

            $body = @{
                code = $code
                client_id = $cfg.ClientId
                client_secret = $cfg.ClientSecret
                redirect_uri = $redirect
                grant_type = 'authorization_code'
            }

            $token = Invoke-RestMethod -Method Post -Uri $cfg.TokenUri -Body $body -ContentType 'application/x-www-form-urlencoded'
            Save-GmailToken $DataDir $token
            return $token
        }
        finally {
            try { $client.Close() } catch {}
        }
    }
    catch {
        throw
    }
    finally {
        try { $tcp.Stop() } catch {}
    }
}

function Get-GmailAccessToken {
    param([string]$Root, [string]$DataDir)

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $cfg = Get-GmailConfig $Root
    $saved = Load-GmailToken $DataDir

    if ($saved -and $saved.access_token -and $saved.expires_at) {
        try {
            if ((Get-Date) -lt [datetime]$saved.expires_at) {
                return [string]$saved.access_token
            }
        }
        catch {}
    }

    if ($saved -and $saved.refresh_token) {
        try {
            $body = @{
                client_id = $cfg.ClientId
                client_secret = $cfg.ClientSecret
                refresh_token = [string]$saved.refresh_token
                grant_type = 'refresh_token'
            }

            $token = Invoke-RestMethod -Method Post -Uri $cfg.TokenUri -Body $body -ContentType 'application/x-www-form-urlencoded'
            if (-not $token.refresh_token) {
                $token | Add-Member -NotePropertyName refresh_token -NotePropertyValue ([string]$saved.refresh_token)
            }

            Save-GmailToken $DataDir $token
            return [string]$token.access_token
        }
        catch {}
    }

    $newToken = Invoke-GmailAuthorization -Root $Root -DataDir $DataDir
    return [string]$newToken.access_token
}

function Convert-ToBase64Lines {
    param([byte[]]$Bytes)
    $b64 = [Convert]::ToBase64String($Bytes)
    $sb = New-Object Text.StringBuilder

    for ($i = 0; $i -lt $b64.Length; $i += 76) {
        $len = [Math]::Min(76, $b64.Length - $i)
        [void]$sb.Append($b64.Substring($i, $len))
        [void]$sb.Append("`r`n")
    }

    return $sb.ToString()
}

function Encode-Rfc2047 {
    param([string]$Text)
    $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
    return '=?UTF-8?B?' + [Convert]::ToBase64String($bytes) + '?='
}

function Convert-ToBase64Url {
    param([byte[]]$Bytes)
    return ([Convert]::ToBase64String($Bytes)).TrimEnd('=').Replace('+','-').Replace('/','_')
}

function Send-GmailMessage {
    param(
        [string]$Root,
        [string]$DataDir,
        [string]$To,
        [string]$Subject,
        [string]$Body,
        $Files
    )

    if ([string]::IsNullOrWhiteSpace($To)) {
        throw 'Не указан E-mail получателя.'
    }

    $token = Get-GmailAccessToken -Root $Root -DataDir $DataDir
    $boundary = 'domlight_' + [guid]::NewGuid().ToString('N')
    $sb = New-Object Text.StringBuilder

    [void]$sb.Append("From: $(Encode-Rfc2047 $script:GmailFromName) <$script:GmailFromAddress>`r`n")
[void]$sb.Append("Reply-To: $script:GmailFromAddress`r`n")
[void]$sb.Append("To: $To`r`n")
    [void]$sb.Append("Subject: $(Encode-Rfc2047 $Subject)`r`n")
    [void]$sb.Append("MIME-Version: 1.0`r`n")
    [void]$sb.Append("Content-Type: multipart/mixed; boundary=`"$boundary`"`r`n`r`n")

    [void]$sb.Append("--$boundary`r`n")
    [void]$sb.Append("Content-Type: text/plain; charset=`"UTF-8`"`r`n")
    [void]$sb.Append("Content-Transfer-Encoding: base64`r`n`r`n")
    [void]$sb.Append((Convert-ToBase64Lines ([Text.Encoding]::UTF8.GetBytes($Body))))
    [void]$sb.Append("`r`n")

    foreach ($file in @($Files)) {
        if (-not (Test-Path -LiteralPath $file)) {
            throw "Не найден файл: $file"
        }

        $filename = [IO.Path]::GetFileName([string]$file)
        $encodedName = Encode-Rfc2047 $filename
        $bytes = [IO.File]::ReadAllBytes([string]$file)

        [void]$sb.Append("--$boundary`r`n")
        [void]$sb.Append("Content-Type: application/pdf; name=`"$encodedName`"`r`n")
        [void]$sb.Append("Content-Disposition: attachment; filename=`"$encodedName`"`r`n")
        [void]$sb.Append("Content-Transfer-Encoding: base64`r`n`r`n")
        [void]$sb.Append((Convert-ToBase64Lines $bytes))
        [void]$sb.Append("`r`n")
    }

    [void]$sb.Append("--$boundary--`r`n")

    $rawBytes = [Text.Encoding]::UTF8.GetBytes($sb.ToString())
    $raw = Convert-ToBase64Url $rawBytes
    $payload = @{ raw = $raw } | ConvertTo-Json -Compress
    $headers = @{ Authorization = "Bearer $token" }

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    return Invoke-RestMethod `
        -Method Post `
        -Uri 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send' `
        -Headers $headers `
        -ContentType 'application/json; charset=utf-8' `
        -Body ([Text.Encoding]::UTF8.GetBytes($payload))
}
