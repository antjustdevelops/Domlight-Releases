﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web

Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;

public static class DomlightWindowTools {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll")]
    public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    public static IntPtr FindVisibleWindowByTitleContains(string part) {
        IntPtr found = IntPtr.Zero;
        EnumWindows(delegate(IntPtr hWnd, IntPtr lParam) {
            if (!IsWindowVisible(hWnd)) return true;
            StringBuilder sb = new StringBuilder(512);
            GetWindowText(hWnd, sb, sb.Capacity);
            string title = sb.ToString();
            if (!String.IsNullOrEmpty(title) &&
                title.IndexOf(part, StringComparison.OrdinalIgnoreCase) >= 0) {
                found = hWnd;
                return false;
            }
            return true;
        }, IntPtr.Zero);
        return found;
    }
}
"@

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

$createdNew = $false
$script:mailingMutex = New-Object Threading.Mutex($true, "Global\DomlightMailingWindow", [ref]$createdNew)
if (-not $createdNew) {
    [Windows.Forms.MessageBox]::Show(
        "Окно рассылки уже открыто.",
        "Domlight",
        "OK",
        "Information"
    ) | Out-Null
    exit
}

$DataDir = Join-Path $Root 'data'
$ReceiptsDir = Join-Path $DataDir 'receipts'
$OutboxRoot = Join-Path $DataDir 'outbox'
$RecipientsFile = Join-Path $DataDir 'recipients.json'
$EmailHistoryFile = Join-Path $DataDir 'email_history.json'
$WhatsAppHistoryFile = Join-Path $DataDir 'whatsapp_history.json'
$IconFile = Join-Path $Root 'Domlight.ico'
$ScannerFile = Join-Path $Root 'ReceiptScanner.ps1'
$GmailApiFile = Join-Path $Root 'GmailApi.ps1'
. $GmailApiFile
$RecipientsUiFile = Join-Path $Root 'Recipients.ps1'

New-Item -ItemType Directory -Force -Path $OutboxRoot | Out-Null

function Safe-Name {
    param([string]$Text)
    foreach ($c in [IO.Path]::GetInvalidFileNameChars()) {
        $Text = $Text.Replace([string]$c, '_')
    }
    return $Text
}

function Load-Recipients {
    $map = @{}
    if (Test-Path $RecipientsFile) {
        try {
            $items = @(Get-Content $RecipientsFile -Raw -Encoding UTF8 | ConvertFrom-Json)
            foreach ($item in $items) {
                $map[[string]$item.Account] = $item
            }
        }
        catch {}
    }
    return $map
}


function Save-Recipients {
    param($Rows)

    $items = @()
    foreach ($r in @($Rows)) {
        if ([string]::IsNullOrWhiteSpace([string]$r.Account)) { continue }

        $items += [pscustomobject]@{
            Account = [string]$r.Account
            Apartment = [string]$r.Apartment
            Recipient = [string]$r.Recipient
            Email = [string]$r.Email
            WhatsApp = [string]$r.WhatsApp
        }
    }

    $items | ConvertTo-Json -Depth 4 | Set-Content $RecipientsFile -Encoding UTF8
}


function Load-EmailHistory {
    $result = New-Object System.Collections.Generic.List[string]

    # Previously remembered addresses.
    if (Test-Path $EmailHistoryFile) {
        try {
            foreach ($value in @(Get-Content $EmailHistoryFile -Raw -Encoding UTF8 | ConvertFrom-Json)) {
                $emailValue = ([string]$value).Trim()
                if (-not [string]::IsNullOrWhiteSpace($emailValue) -and -not $result.Contains($emailValue)) {
                    $result.Add($emailValue)
                }
            }
        }
        catch {}
    }

    # Also pick up e-mails that already exist in recipients.json.
    if (Test-Path $RecipientsFile) {
        try {
            foreach ($item in @(Get-Content $RecipientsFile -Raw -Encoding UTF8 | ConvertFrom-Json)) {
                $emailValue = ([string]$item.Email).Trim()
                if (-not [string]::IsNullOrWhiteSpace($emailValue) -and -not $result.Contains($emailValue)) {
                    $result.Add($emailValue)
                }
            }
        }
        catch {}
    }

    return @($result)
}

function Save-EmailHistory {
    param($Emails)

    $unique = @(
        $Emails |
        ForEach-Object { ([string]$_).Trim() } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
        Select-Object -Unique
    )

    $unique | ConvertTo-Json | Set-Content $EmailHistoryFile -Encoding UTF8
}

$script:EmailHistory = @(Load-EmailHistory)

function Load-WhatsAppHistory {
    $result = New-Object System.Collections.Generic.List[string]

    if (Test-Path $WhatsAppHistoryFile) {
        try {
            foreach ($value in @(Get-Content $WhatsAppHistoryFile -Raw -Encoding UTF8 | ConvertFrom-Json)) {
                $phone = ([string]$value).Trim()
                if (-not [string]::IsNullOrWhiteSpace($phone) -and -not $result.Contains($phone)) {
                    $result.Add($phone)
                }
            }
        }
        catch {}
    }

    if (Test-Path $RecipientsFile) {
        try {
            foreach ($item in @(Get-Content $RecipientsFile -Raw -Encoding UTF8 | ConvertFrom-Json)) {
                $phone = ([string]$item.WhatsApp).Trim()
                if (-not [string]::IsNullOrWhiteSpace($phone) -and -not $result.Contains($phone)) {
                    $result.Add($phone)
                }
            }
        }
        catch {}
    }

    return @($result)
}

function Save-WhatsAppHistory {
    param($Phones)

    $unique = @(
        $Phones |
        ForEach-Object { ([string]$_).Trim() } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
        Select-Object -Unique
    )

    $unique | ConvertTo-Json | Set-Content $WhatsAppHistoryFile -Encoding UTF8
}

$script:WhatsAppHistory = @(Load-WhatsAppHistory)

function Remember-WhatsApp {
    param([string]$Phone)

    $Phone = ([string]$Phone).Trim()
    if ([string]::IsNullOrWhiteSpace($Phone)) { return }

    if ($script:WhatsAppHistory -notcontains $Phone) {
        $script:WhatsAppHistory += $Phone
        Save-WhatsAppHistory $script:WhatsAppHistory
    }
}

function Apply-WhatsAppAutoComplete {
    param([Windows.Forms.TextBox]$TextBox)

    $source = New-Object Windows.Forms.AutoCompleteStringCollection
    foreach ($phone in @($script:WhatsAppHistory)) {
        [void]$source.Add([string]$phone)
    }

    $TextBox.AutoCompleteMode = [Windows.Forms.AutoCompleteMode]::SuggestAppend
    $TextBox.AutoCompleteSource = [Windows.Forms.AutoCompleteSource]::CustomSource
    $TextBox.AutoCompleteCustomSource = $source
}


function Remember-Email {
    param([string]$Address)

    $Address = ([string]$Address).Trim()
    if ([string]::IsNullOrWhiteSpace($Address)) { return }

    if ($script:EmailHistory -notcontains $Address) {
        $script:EmailHistory += $Address
        Save-EmailHistory $script:EmailHistory
    }
}

function Apply-EmailAutoComplete {
    param([Windows.Forms.TextBox]$TextBox)

    $source = New-Object Windows.Forms.AutoCompleteStringCollection
    foreach ($address in @($script:EmailHistory)) {
        [void]$source.Add([string]$address)
    }

    $TextBox.AutoCompleteMode = [Windows.Forms.AutoCompleteMode]::SuggestAppend
    $TextBox.AutoCompleteSource = [Windows.Forms.AutoCompleteSource]::CustomSource
    $TextBox.AutoCompleteCustomSource = $source
}

function Prepare-Outbox {
    param($Items, [string]$Period)

    # outbox stores only the latest prepared set.
    New-Item -ItemType Directory -Force -Path $OutboxRoot | Out-Null

    # Remove every previously prepared folder/file before creating the new one.
    Get-ChildItem -LiteralPath $OutboxRoot -Force -ErrorAction SilentlyContinue | ForEach-Object {
        Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction Stop
    }

    $dest = Join-Path $OutboxRoot (Get-Date -Format 'yyyy-MM-dd_HH-mm-ss')
    New-Item -ItemType Directory -Force -Path $dest | Out-Null

    $prepared = @()
    foreach ($item in @($Items)) {
        $apartment = if ([string]::IsNullOrWhiteSpace([string]$item.Apartment)) {
            'ЛС_' + [string]$item.Account
        }
        else {
            'кв. ' + [string]$item.Apartment
        }

        $receiptType = if ([string]::IsNullOrWhiteSpace([string]$item.Type)) { 'ЖКХ' } else { [string]$item.Type }
        $name = Safe-Name ("Квитанция $receiptType — $apartment — $Period.pdf")
        $target = Join-Path $dest $name
        Copy-Item -LiteralPath ([string]$item.PdfPath) -Destination $target -Force

        $prepared += [pscustomobject]@{
            Account = [string]$item.Account
            Apartment = [string]$item.Apartment
            Type = $receiptType
            File = $target
        }
    }

    return [pscustomobject]@{
        Folder = $dest
        Items = $prepared
    }
}

function Open-WebUrl {
    param([Parameter(Mandatory=$true)][string]$Url)

    $errors = @()

    # Primary method for Windows PowerShell / .NET Framework:
    # let Windows open the URL with the user's default browser.
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $Url
        $psi.UseShellExecute = $true
        [void][System.Diagnostics.Process]::Start($psi)
        return
    }
    catch {
        $errors += "Windows: " + $_.Exception.Message
    }

    # Fallback through the standard Windows URL protocol handler.
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "rundll32.exe"
        $psi.Arguments = 'url.dll,FileProtocolHandler "' + $Url.Replace('"','""') + '"'
        $psi.UseShellExecute = $true
        [void][System.Diagnostics.Process]::Start($psi)
        return
    }
    catch {
        $errors += "URL-handler: " + $_.Exception.Message
    }

    # Fallback: Microsoft Edge directly.
    $edgeCandidates = @(
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
    )
    foreach ($edge in $edgeCandidates) {
        if ($edge -and (Test-Path $edge)) {
            try {
                $psi = New-Object System.Diagnostics.ProcessStartInfo
                $psi.FileName = $edge
                $psi.Arguments = '--new-window "' + $Url.Replace('"','""') + '"'
                $psi.UseShellExecute = $true
                [void][System.Diagnostics.Process]::Start($psi)
                return
            }
            catch {
                $errors += "Edge: " + $_.Exception.Message
            }
        }
    }

    # Fallback: Chrome directly.
    $chromeCandidates = @(
        (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach ($chrome in $chromeCandidates) {
        if ($chrome -and (Test-Path $chrome)) {
            try {
                $psi = New-Object System.Diagnostics.ProcessStartInfo
                $psi.FileName = $chrome
                $psi.Arguments = '--new-window "' + $Url.Replace('"','""') + '"'
                $psi.UseShellExecute = $true
                [void][System.Diagnostics.Process]::Start($psi)
                return
            }
            catch {
                $errors += "Chrome: " + $_.Exception.Message
            }
        }
    }

    throw ("Не удалось открыть браузер. " + ($errors -join " | "))
}

function Put-FilesOnClipboard {
    param($Files)

    $list = New-Object Collections.Specialized.StringCollection
    foreach ($file in @($Files)) {
        if (Test-Path $file) {
            [void]$list.Add([string]$file)
        }
    }

    if ($list.Count -gt 0) {
        [Windows.Forms.Clipboard]::SetFileDropList($list)
    }

    return $list.Count
}

function Gmail-Send {
    param([string]$To, [string]$Subject, [string]$Body, $Files)

    try {
        $existing = @($Files | Where-Object { Test-Path -LiteralPath $_ })
        if ($existing.Count -eq 0) {
            throw 'Нет PDF для прикрепления.'
        }

        [void](Send-GmailMessage `
            -Root $Root `
            -DataDir $DataDir `
            -To $To `
            -Subject $Subject `
            -Body $Body `
            -Files $existing)

        [Windows.Forms.MessageBox]::Show(
            "Письмо отправлено через Gmail.`r`n`r`nPDF-вложений: $($existing.Count)",
            'Gmail',
            'OK',
            'Information'
        ) | Out-Null
    }
    catch {
        [Windows.Forms.MessageBox]::Show(
            "Не удалось отправить через Gmail:`r`n`r`n$($_.Exception.Message)",
            'Gmail',
            'OK',
            'Error'
        ) | Out-Null
    }
}


function Arrange-WhatsAppAndExplorer {
    param([string]$ExplorerFolder)

    try {
        Start-Sleep -Milliseconds 1200

        $screen = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $gap = 8
        $leftWidth = [int](($screen.Width - $gap) * 0.52)
        $rightWidth = $screen.Width - $leftWidth - $gap

        # Find WhatsApp by visible window title.
        $waHwnd = [DomlightWindowTools]::FindVisibleWindowByTitleContains('WhatsApp')

        # Find Explorer window by exact folder path through Shell.Application.
        $explorerHwnd = [IntPtr]::Zero
        try {
            $shell = New-Object -ComObject Shell.Application
            foreach ($w in @($shell.Windows())) {
                try {
                    $path = [string]$w.Document.Folder.Self.Path
                    if ($path -and ([IO.Path]::GetFullPath($path)).TrimEnd('\') -eq
                        ([IO.Path]::GetFullPath($ExplorerFolder)).TrimEnd('\')) {
                        $explorerHwnd = [IntPtr]([long]$w.HWND)
                        break
                    }
                } catch {}
            }
        } catch {}

        if ($waHwnd -ne [IntPtr]::Zero) {
            [void][DomlightWindowTools]::ShowWindow($waHwnd, 9) # restore
            [void][DomlightWindowTools]::MoveWindow(
                $waHwnd,
                $screen.X,
                $screen.Y,
                $leftWidth,
                $screen.Height,
                $true
            )
        }

        if ($explorerHwnd -ne [IntPtr]::Zero) {
            [void][DomlightWindowTools]::ShowWindow($explorerHwnd, 9) # restore
            [void][DomlightWindowTools]::MoveWindow(
                $explorerHwnd,
                $screen.X + $leftWidth + $gap,
                $screen.Y,
                $rightWidth,
                $screen.Height,
                $true
            )
        }
    }
    catch {
        # Positioning is only a convenience; never block normal WhatsApp workflow.
    }
}

function WhatsApp-Open {
    param([string]$Phone, [string]$Text, $Files)

    $digits = $Phone -replace '\D', ''
    if ($digits.StartsWith('8') -and $digits.Length -eq 11) {
        $digits = '7' + $digits.Substring(1)
    }

    if ([string]::IsNullOrWhiteSpace($digits)) {
        [Windows.Forms.MessageBox]::Show(
            'Введите номер WhatsApp.',
            'WhatsApp',
            'OK',
            'Warning'
        ) | Out-Null
        return
    }

    $existing = @($Files | Where-Object { Test-Path -LiteralPath $_ })
    if ($existing.Count -eq 0) {
        [Windows.Forms.MessageBox]::Show(
            'Нет PDF для отправки.',
            'WhatsApp',
            'OK',
            'Warning'
        ) | Out-Null
        return
    }

    try {
        # Open installed WhatsApp Desktop directly to the requested chat.
        $url = "whatsapp://send?phone=" + $digits +
               "&text=" + [Web.HttpUtility]::UrlEncode($Text)

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $url
        $psi.UseShellExecute = $true
        [void][System.Diagnostics.Process]::Start($psi)

        Start-Sleep -Milliseconds 900

        # Open Explorer and select the exact PDF for this row.
        # For multiple files, open the prepared folder.
        if ($existing.Count -eq 1) {
            $file = [string]$existing[0]
            $folder = Split-Path -Parent $file
            Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $file + '"')
        }
        else {
            $folder = Split-Path -Parent ([string]$existing[0])
            Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $folder + '"')
        }

        # Put WhatsApp on the left and Explorer with PDFs on the right.
        Arrange-WhatsAppAndExplorer -ExplorerFolder $folder

        $msg = if ($existing.Count -eq 1) {
            "WhatsApp открыт на нужном чате.`r`n`r`n" +
            "Папка открыта, нужный PDF уже выделен.`r`n" +
            "Перетащите выделенный файл мышкой в чат и нажмите «Отправить»."
        }
        else {
            "WhatsApp открыт на нужном чате.`r`n`r`n" +
            "Открыта папка с актуальными PDF.`r`n" +
            "Выделите нужные файлы и перетащите их мышкой в чат."
        }

        [Windows.Forms.MessageBox]::Show(
            $msg,
            'WhatsApp',
            'OK',
            'Information'
        ) | Out-Null
    }
    catch {
        [Windows.Forms.MessageBox]::Show(
            "Не удалось открыть WhatsApp или папку с PDF:`r`n`r`n$($_.Exception.Message)",
            'WhatsApp',
            'OK',
            'Error'
        ) | Out-Null
    }
}

$form = New-Object Windows.Forms.Form
$form.Text = 'Domlight — Рассылка квитанций'
$screen = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$windowWidth = [Math]::Min(1500, ([int]$screen.Width - 40))
$windowHeight = [Math]::Min(860, ([int]$screen.Height - 40))
$form.Size = New-Object Drawing.Size -ArgumentList $windowWidth,$windowHeight
$form.StartPosition = 'CenterScreen'
$form.BackColor = [Drawing.Color]::FromArgb(245,247,250)
$form.Font = New-Object Drawing.Font('Segoe UI', 10)
$form.FormBorderStyle = 'Sizable'
$form.MaximizeBox = $true
if (Test-Path $IconFile) {
    try { $form.Icon = New-Object Drawing.Icon($IconFile) } catch {}
}

$title = New-Object Windows.Forms.Label
$title.Text = 'Рассылка квитанций'
$title.Font = New-Object Drawing.Font('Segoe UI', 20, [Drawing.FontStyle]::Bold)
$title.Location = New-Object Drawing.Point(28,18)
$title.AutoSize = $true
$form.Controls.Add($title)

$subtitle = New-Object Windows.Forms.Label
$subtitle.Text = 'Сначала выберите, какие квитанции подготовить: ЖКХ, капремонт или полный комплект.'
$subtitle.Location = New-Object Drawing.Point(31,60)
$subtitle.Size = New-Object Drawing.Size -ArgumentList 500,35
$subtitle.Anchor = 'Top,Left,Right'
$subtitle.ForeColor = [Drawing.Color]::DimGray
$form.Controls.Add($subtitle)

$status = New-Object Windows.Forms.Label
$status.Text = 'Подготавливаю анализ...'
$status.Location = New-Object Drawing.Point(31,103)
$status.Size = New-Object Drawing.Size -ArgumentList 500,28
$status.Anchor = 'Top,Left,Right'
$status.Font = New-Object Drawing.Font('Segoe UI',10,[Drawing.FontStyle]::Bold)
$form.Controls.Add($status)

$progress = New-Object Windows.Forms.ProgressBar
$progress.Location = New-Object Drawing.Point(31,134)
$progress.Size = New-Object Drawing.Size -ArgumentList 500,10
$progress.Anchor = 'Top,Left,Right'
$progress.Style = 'Marquee'
$form.Controls.Add($progress)

$grid = New-Object Windows.Forms.DataGridView
$grid.Location = New-Object Drawing.Point(31,160)
$grid.Size = New-Object Drawing.Size -ArgumentList 1100,300
$grid.Width = [Math]::Max(900, ([int]$form.ClientSize.Width - 62))
$grid.Anchor = 'Top,Left,Right'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.RowHeadersVisible = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.MultiSelect = $false
$grid.BackgroundColor = [Drawing.Color]::White
$grid.AutoGenerateColumns = $false
$grid.ScrollBars = 'Both'

function Add-GridTextColumn {
    param(
        [string]$Name,
        [string]$Header,
        [int]$Width,
        [bool]$ReadOnly
    )

    $c = New-Object Windows.Forms.DataGridViewTextBoxColumn
    $c.Name = $Name
    $c.HeaderText = $Header
    $c.Width = $Width
    $c.ReadOnly = $ReadOnly
    [void]$grid.Columns.Add($c)
}

$selectCol = New-Object Windows.Forms.DataGridViewCheckBoxColumn
$selectCol.Name = 'Selected'
$selectCol.HeaderText = '☑'
$selectCol.Width = 48
$selectCol.ReadOnly = $false
$selectCol.ThreeState = $false
[void]$grid.Columns.Add($selectCol)

$script:allSelected = $true
$grid.Columns['Selected'].HeaderCell.ToolTipText = 'Нажмите, чтобы выбрать все / снять все'

Add-GridTextColumn 'Apartment' 'Квартира' 72 $true
Add-GridTextColumn 'Period' 'Период' 72 $true
Add-GridTextColumn 'Type' 'Тип' 100 $true
Add-GridTextColumn 'Recipient' 'Получатель' 125 $false
Add-GridTextColumn 'Email' 'E-mail' 200 $false
Add-GridTextColumn 'WhatsApp' 'WhatsApp' 135 $false

$mailCol = New-Object Windows.Forms.DataGridViewButtonColumn
$mailCol.Name = 'SendMail'
$mailCol.HeaderText = 'Mail'
$mailCol.Text = 'Mail'
$mailCol.UseColumnTextForButtonValue = $true
$mailCol.Width = 58
[void]$grid.Columns.Add($mailCol)

$waCol = New-Object Windows.Forms.DataGridViewButtonColumn
$waCol.Name = 'SendWhatsApp'
$waCol.HeaderText = 'WhatsApp'
$waCol.Text = 'WhatsApp'
$waCol.UseColumnTextForButtonValue = $true
$waCol.Width = 78
[void]$grid.Columns.Add($waCol)

Add-GridTextColumn 'PdfName' 'Файл' 280 $true

$viewCol = New-Object Windows.Forms.DataGridViewButtonColumn
$viewCol.Name = 'ViewPdf'
$viewCol.HeaderText = 'PDF'
$viewCol.Text = 'Посмотреть'
$viewCol.UseColumnTextForButtonValue = $true
$viewCol.Width = 92
[void]$grid.Columns.Add($viewCol)
$grid.Columns['PdfName'].AutoSizeMode = [Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
$grid.Columns['PdfName'].MinimumWidth = 260


$form.Add_Resize({
    try {
        $grid.Width = [Math]::Max(900, ([int]$form.ClientSize.Width - 62))
        $subtitle.Width = [Math]::Max(500, ([int]$form.ClientSize.Width - 360))
        $status.Width = [Math]::Max(500, ([int]$form.ClientSize.Width - 360))
        $progress.Width = [Math]::Max(500, ([int]$form.ClientSize.Width - 360))
    } catch {}
})

$grid.Add_EditingControlShowing({
    param($sender, $e)

    if (-not $grid.CurrentCell) { return }

    $tb = $e.Control -as [Windows.Forms.TextBox]
    if (-not $tb) { return }

    $columnName = $grid.CurrentCell.OwningColumn.Name

    if ($columnName -eq 'Email') {
        Apply-EmailAutoComplete $tb
        return
    }

    if ($columnName -eq 'WhatsApp') {
        Apply-WhatsAppAutoComplete $tb
        return
    }
})

$grid.Add_CellEndEdit({
    param($sender, $e)

    if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }

    $columnName = $grid.Columns[$e.ColumnIndex].Name

    if ($columnName -eq 'Email') {
        $value = [string]$grid.Rows[$e.RowIndex].Cells['Email'].Value
        Remember-Email $value
        return
    }

    if ($columnName -eq 'WhatsApp') {
        $value = [string]$grid.Rows[$e.RowIndex].Cells['WhatsApp'].Value
        Remember-WhatsApp $value
        return
    }
})

$form.Controls.Add($grid)

$grid.Add_ColumnHeaderMouseClick({
    param($sender, $e)

    if ($e.ColumnIndex -lt 0) { return }
    if ($grid.Columns[$e.ColumnIndex].Name -ne 'Selected') { return }

    $script:allSelected = -not $script:allSelected
    foreach ($row in $grid.Rows) {
        if (-not $row.IsNewRow) {
            $row.Cells['Selected'].Value = $script:allSelected
        }
    }

    $grid.Columns['Selected'].HeaderText = if ($script:allSelected) { '☑' } else { '☐' }
    $grid.EndEdit()
    $grid.Refresh()
})


function Get-GridRecipientRows {
    $rows = @()

    foreach ($row in $grid.Rows) {
        if ($row.IsNewRow) { continue }

        $rows += [pscustomobject]@{
            Account = [string]$row.Tag
            Apartment = [string]$row.Cells['Apartment'].Value
            Type = [string]$row.Cells['Type'].Value
            Recipient = [string]$row.Cells['Recipient'].Value
            Email = [string]$row.Cells['Email'].Value
            WhatsApp = [string]$row.Cells['WhatsApp'].Value
        }
    }

    return $rows
}

function Save-GridRecipients {
    try {
        $recipientRows = Get-GridRecipientRows
        Save-Recipients $recipientRows
        foreach ($r in @($recipientRows)) {
            Remember-Email ([string]$r.Email)
            Remember-WhatsApp ([string]$r.WhatsApp)
        }
    }
    catch {
        [Windows.Forms.MessageBox]::Show(
            "Не удалось сохранить получателей:`r`n$($_.Exception.Message)",
            'Получатели',
            'OK',
            'Error'
        ) | Out-Null
    }
}

function Get-SelectedScanItems {
    $selected = @()

    if (-not $script:scan) { return $selected }

    foreach ($row in $grid.Rows) {
        if ($row.IsNewRow) { continue }

        $isSelected = $false
        try { $isSelected = [bool]$row.Cells['Selected'].Value } catch {}
        if (-not $isSelected) { continue }

        $account = [string]$row.Tag
        $type = [string]$row.Cells['Type'].Value
        $item = @($script:currentItems | Where-Object {
            [string]$_.Account -eq $account -and [string]$_.Type -eq $type
        } | Select-Object -First 1)

        if ($item.Count -gt 0) {
            $selected += $item[0]
        }
    }

    return $selected
}

function Require-SelectedScanItems {
    $items = @(Get-SelectedScanItems)

    if ($items.Count -eq 0) {
        [Windows.Forms.MessageBox]::Show(
            'Поставьте галочки напротив квитанций, которые нужно использовать.',
            'Квитанции',
            'OK',
            'Warning'
        ) | Out-Null
        return $null
    }

    return $items
}

function Get-ScanItemForRow {
    param($Row)

    if (-not $script:scan -or -not $Row) { return $null }
    $account = [string]$Row.Tag
    $type = [string]$Row.Cells['Type'].Value

    return @($script:currentItems | Where-Object {
        [string]$_.Account -eq $account -and [string]$_.Type -eq $type
    } | Select-Object -First 1)[0]
}

function Load-PreparedFilesIntoGrid {
    param($Prepared)

    $map = @{}
    foreach ($p in @($Prepared.Items)) {
        $key = ([string]$p.Account) + '|' + ([string]$p.Type)
        $map[$key] = [string]$p.File
    }

    foreach ($row in $grid.Rows) {
        if ($row.IsNewRow) { continue }

        $key = ([string]$row.Tag) + '|' + ([string]$row.Cells['Type'].Value)
        if ($map.ContainsKey($key)) {
            $row.Cells['PdfName'].Value = [IO.Path]::GetFileName($map[$key])
            $row.Cells['PdfName'].Tag = $map[$key]
        }
    }
}

$mode = New-Object Windows.Forms.GroupBox
$mode.Text = 'Отправка'
$mode.Location = New-Object Drawing.Point(31,475)
$mode.Size = New-Object Drawing.Size(1100,105)
$form.Controls.Add($mode)

$one = New-Object Windows.Forms.RadioButton
$one.Text = 'Все одному получателю'
$one.Location = New-Object Drawing.Point(15,26)
$one.Size = New-Object Drawing.Size(215,24)
$one.Checked = $true
$mode.Controls.Add($one)

$each = New-Object Windows.Forms.RadioButton
$each.Text = 'Каждую своему получателю'
$each.Location = New-Object Drawing.Point(15,62)
$each.Size = New-Object Drawing.Size(230,24)
$mode.Controls.Add($each)

$emailLabel = New-Object Windows.Forms.Label
$emailLabel.Text = 'E-mail'
$emailLabel.Location = New-Object Drawing.Point(300,14)
$emailLabel.AutoSize = $true
$mode.Controls.Add($emailLabel)

$email = New-Object Windows.Forms.TextBox
$email.Location = New-Object Drawing.Point(300,35)
$email.Size = New-Object Drawing.Size(320,27)
$mode.Controls.Add($email)
Apply-EmailAutoComplete $email
$email.Add_Leave({
    Remember-Email $email.Text
    Apply-EmailAutoComplete $email
})

$waLabel = New-Object Windows.Forms.Label
$waLabel.Text = 'WhatsApp'
$waLabel.Location = New-Object Drawing.Point(650,14)
$waLabel.AutoSize = $true
$mode.Controls.Add($waLabel)

$wa = New-Object Windows.Forms.TextBox
$wa.Location = New-Object Drawing.Point(650,35)
$wa.Size = New-Object Drawing.Size(260,27)
$mode.Controls.Add($wa)
Apply-WhatsAppAutoComplete $wa
$wa.Add_Leave({
    Remember-WhatsApp $wa.Text
    Apply-WhatsAppAutoComplete $wa
})

function Update-RecipientMode {
    $email.Enabled = $one.Checked
    $wa.Enabled = $one.Checked

    $perRowReadOnly = $one.Checked
    $grid.Columns['Recipient'].ReadOnly = $perRowReadOnly
    $grid.Columns['Email'].ReadOnly = $perRowReadOnly
    $grid.Columns['WhatsApp'].ReadOnly = $perRowReadOnly

    if ($one.Checked) {
        $modeHint.Text = 'Галочками выберите квитанции. Используются общий E-mail/WhatsApp; контакты строк игнорируются.'
    }
    else {
        $modeHint.Text = 'Галочками выберите квитанции. Для каждой квартиры используются контакты из её строки.'
    }
}

$one.Add_CheckedChanged({ Update-RecipientMode })
$each.Add_CheckedChanged({
    if (-not $each.Checked) { return }
    Update-RecipientMode
})

$modeHint = New-Object Windows.Forms.Label
$modeHint.Text = 'Галочками выберите квитанции. Используются общий E-mail/WhatsApp; контакты строк игнорируются.'
$modeHint.Location = New-Object Drawing.Point(300,70)
$modeHint.Size = New-Object Drawing.Size(760,24)
$modeHint.ForeColor = [Drawing.Color]::DimGray
$mode.Controls.Add($modeHint)

$prepareButton = New-Object Windows.Forms.Button
$prepareButton.Text = 'Подготовить PDF'
$prepareButton.Location = New-Object Drawing.Point(31,595)
$prepareButton.Size = New-Object Drawing.Size(180,38)
$form.Controls.Add($prepareButton)

$outboxButton = New-Object Windows.Forms.Button
$outboxButton.Text = 'Папка подготовленных'
$outboxButton.Location = New-Object Drawing.Point(225,595)
$outboxButton.Size = New-Object Drawing.Size(200,38)
$form.Controls.Add($outboxButton)

$emailButton = New-Object Windows.Forms.Button
$emailButton.Text = 'Отправить Gmail + PDF'
$emailButton.Location = New-Object Drawing.Point(445,590)
$emailButton.Size = New-Object Drawing.Size(330,48)
$emailButton.FlatStyle = 'Flat'
$emailButton.FlatAppearance.BorderSize = 0
$emailButton.BackColor = [Drawing.Color]::FromArgb(37,99,235)
$emailButton.ForeColor = [Drawing.Color]::White
$emailButton.Enabled = $false
$form.Controls.Add($emailButton)

$waButton = New-Object Windows.Forms.Button
$waButton.Text = 'WhatsApp + открыть PDF'
$waButton.Location = New-Object Drawing.Point(795,590)
$waButton.Size = New-Object Drawing.Size(336,48)
$waButton.FlatStyle = 'Flat'
$waButton.FlatAppearance.BorderSize = 0
$waButton.BackColor = [Drawing.Color]::FromArgb(22,163,74)
$waButton.ForeColor = [Drawing.Color]::White
$waButton.Enabled = $false
$form.Controls.Add($waButton)


# Start-of-task mode chooser. It covers the work area until the user selects what to prepare.
$chooser = New-Object Windows.Forms.Panel
$chooser.Location = New-Object Drawing.Point(20,95)
$chooser.Size = New-Object Drawing.Size(1120,555)
$chooser.Anchor = 'Top,Bottom,Left,Right'
$chooser.BackColor = [Drawing.Color]::FromArgb(245,247,250)
$form.Controls.Add($chooser)

$chooserTitle = New-Object Windows.Forms.Label
$chooserTitle.Text = 'Что подготовить для отправки?'
$chooserTitle.Font = New-Object Drawing.Font('Segoe UI',18,[Drawing.FontStyle]::Bold)
$chooserTitle.Location = New-Object Drawing.Point(55,55)
$chooserTitle.AutoSize = $true
$chooser.Controls.Add($chooserTitle)

$chooserInfo = New-Object Windows.Forms.Label
$chooserInfo.Text = 'Анализирую квитанции…'
$chooserInfo.Font = New-Object Drawing.Font('Segoe UI',11)
$chooserInfo.Location = New-Object Drawing.Point(58,105)
$chooserInfo.Size = New-Object Drawing.Size(980,32)
$chooserInfo.ForeColor = [Drawing.Color]::DimGray
$chooser.Controls.Add($chooserInfo)

$chooseJkh = New-Object Windows.Forms.Button
$chooseJkh.Text = 'Подготовить ЖКХ'
$chooseJkh.Location = New-Object Drawing.Point(60,175)
$chooseJkh.Size = New-Object Drawing.Size(300,70)
$chooseJkh.Font = New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold)
$chooseJkh.BackColor = [Drawing.Color]::FromArgb(226,232,240)
$chooseJkh.ForeColor = [Drawing.Color]::FromArgb(30,41,59)
$chooseJkh.FlatStyle = 'Flat'
$chooseJkh.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(148,163,184)
$chooseJkh.Enabled = $false
$chooser.Controls.Add($chooseJkh)

$chooseCap = New-Object Windows.Forms.Button
$chooseCap.Text = 'Подготовить капремонт'
$chooseCap.Location = New-Object Drawing.Point(390,175)
$chooseCap.Size = New-Object Drawing.Size(300,70)
$chooseCap.Font = New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold)
$chooseCap.BackColor = [Drawing.Color]::FromArgb(226,232,240)
$chooseCap.ForeColor = [Drawing.Color]::FromArgb(30,41,59)
$chooseCap.FlatStyle = 'Flat'
$chooseCap.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(148,163,184)
$chooseCap.Enabled = $false
$chooser.Controls.Add($chooseCap)

$chooseAll = New-Object Windows.Forms.Button
$chooseAll.Text = 'Подготовить все квитанции'
$chooseAll.Location = New-Object Drawing.Point(720,175)
$chooseAll.Size = New-Object Drawing.Size(300,70)
$chooseAll.Font = New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold)
$chooseAll.BackColor = [Drawing.Color]::FromArgb(226,232,240)
$chooseAll.ForeColor = [Drawing.Color]::FromArgb(30,41,59)
$chooseAll.FlatStyle = 'Flat'
$chooseAll.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(148,163,184)
$chooseAll.Enabled = $false
$chooser.Controls.Add($chooseAll)

$chooserHint = New-Object Windows.Forms.Label
$chooserHint.Text = 'ЖКХ и капремонт хранятся отдельно в архиве. Режим можно сменить в любой момент.'
$chooserHint.Location = New-Object Drawing.Point(60,275)
$chooserHint.Size = New-Object Drawing.Size(960,45)
$chooserHint.ForeColor = [Drawing.Color]::DimGray
$chooser.Controls.Add($chooserHint)

$backButton = New-Object Windows.Forms.Button
$backButton.Text = '← Назад к выбору типа'
$backButton.Location = New-Object Drawing.Point(($form.ClientSize.Width - 285),100)
$backButton.Size = New-Object Drawing.Size(255,38)
$backButton.Anchor = 'Top,Right'
$backButton.BackColor = [Drawing.Color]::FromArgb(71,85,105)
$backButton.ForeColor = [Drawing.Color]::White
$backButton.FlatStyle = 'Flat'
$backButton.FlatAppearance.BorderSize = 0
$backButton.Font = New-Object Drawing.Font('Segoe UI',10,[Drawing.FontStyle]::Bold)
$backButton.Visible = $false
$form.Controls.Add($backButton)

$script:currentMode = ''
$script:currentItems = @()

$script:fullMailingSize = $form.Size
$script:compactChooserSize = New-Object Drawing.Size -ArgumentList 620,610

function Center-MailingWindow {
    $wa = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $left = [Math]::Max($wa.Left, $wa.Left + [int](($wa.Width - $form.Width) / 2))
    $top = [Math]::Max($wa.Top, $wa.Top + [int](($wa.Height - $form.Height) / 2))
    $form.StartPosition = 'Manual'
    $form.Location = New-Object Drawing.Point -ArgumentList $left,$top
}


function Set-MailingWorkAreaVisible {
    param([bool]$Show)

    $script:grid.Visible = $Show
    $script:mode.Visible = $Show
    $script:prepareButton.Visible = $Show
    $script:outboxButton.Visible = $Show
    $script:emailButton.Visible = $Show
    $script:waButton.Visible = $Show
}

function Show-CompactChooser {
    Set-MailingWorkAreaVisible $false
    $backButton.Visible = $false
    $chooser.Visible = $true

    $form.Size = $script:compactChooserSize
    Center-MailingWindow

    $clientW = [int]$form.ClientSize.Width
    $contentW = [Math]::Min(540, $clientW - 50)
    $contentX = [int](($clientW - $contentW) / 2)

    # Center all top text by actual window width.
    $title.AutoSize = $false
    $title.Location = New-Object Drawing.Point -ArgumentList $contentX,18
    $title.Size = New-Object Drawing.Size -ArgumentList $contentW,42
    $title.TextAlign = 'MiddleCenter'

    $subtitle.Location = New-Object Drawing.Point -ArgumentList $contentX,58
    $subtitle.Size = New-Object Drawing.Size -ArgumentList $contentW,44
    $subtitle.Text = 'Выберите, какие квитанции подготовить для отправки.'
    $subtitle.TextAlign = 'MiddleCenter'

    $status.Location = New-Object Drawing.Point -ArgumentList $contentX,101
    $status.Size = New-Object Drawing.Size -ArgumentList $contentW,56
    $status.TextAlign = 'MiddleCenter'
    $status.AutoEllipsis = $false

    $progress.Location = New-Object Drawing.Point -ArgumentList $contentX,159
    $progress.Size = New-Object Drawing.Size -ArgumentList $contentW,8

    # Central chooser panel.
    $chooserW = [Math]::Min(560, $clientW - 36)
    $chooserX = [int](($clientW - $chooserW) / 2)
    $chooser.Location = New-Object Drawing.Point -ArgumentList $chooserX,178
    $chooser.Size = New-Object Drawing.Size -ArgumentList $chooserW,382

    $chooserTitle.AutoSize = $false
    $chooserTitle.Location = New-Object Drawing.Point -ArgumentList 25,15
    $chooserTitle.Size = New-Object Drawing.Size -ArgumentList ($chooserW - 50),40
    $chooserTitle.TextAlign = 'MiddleCenter'

    $chooserInfo.Location = New-Object Drawing.Point -ArgumentList 25,58
    $chooserInfo.Size = New-Object Drawing.Size -ArgumentList ($chooserW - 50),38
    $chooserInfo.TextAlign = 'MiddleCenter'

    $buttonW = [Math]::Min(440, $chooserW - 80)
    $buttonX = [int](($chooserW - $buttonW) / 2)
    $buttonH = 58

    $chooseJkh.Location = New-Object Drawing.Point -ArgumentList $buttonX,108
    $chooseJkh.Size = New-Object Drawing.Size -ArgumentList $buttonW,$buttonH

    $chooseCap.Location = New-Object Drawing.Point -ArgumentList $buttonX,177
    $chooseCap.Size = New-Object Drawing.Size -ArgumentList $buttonW,$buttonH

    $chooseAll.Location = New-Object Drawing.Point -ArgumentList $buttonX,246
    $chooseAll.Size = New-Object Drawing.Size -ArgumentList $buttonW,$buttonH

    foreach ($b in @($chooseJkh,$chooseCap,$chooseAll)) {
        $b.BackColor = [Drawing.Color]::FromArgb(226,232,240)
        $b.ForeColor = [Drawing.Color]::FromArgb(30,41,59)
        $b.FlatStyle = 'Flat'
        $b.FlatAppearance.BorderSize = 1
        $b.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(148,163,184)
        $b.Cursor = [Windows.Forms.Cursors]::Hand
    }

    $chooserHint.Location = New-Object Drawing.Point -ArgumentList 30,315
    $chooserHint.Size = New-Object Drawing.Size -ArgumentList ($chooserW - 60),54
    $chooserHint.TextAlign = 'MiddleCenter'
    $chooserHint.Text = 'После выбора откроется список для отправки. Режим можно изменить кнопкой «Назад к выбору типа».'

    $chooser.BringToFront()
    $chooser.Invalidate()
    $chooser.Refresh()
}

function Show-FullMailingView {
    $form.Size = $script:fullMailingSize
    Center-MailingWindow

    $title.AutoSize = $true
    $title.Location = New-Object Drawing.Point(28,18)
    $title.TextAlign = 'MiddleLeft'

    $subtitle.Location = New-Object Drawing.Point(31,60)
    $subtitle.Text = 'Выберите квитанции и способ отправки.'
    $subtitle.Size = New-Object Drawing.Size -ArgumentList ([Math]::Max(500, ([int]$form.ClientSize.Width - 360))),35
    $subtitle.TextAlign = 'MiddleLeft'

    $status.Location = New-Object Drawing.Point(31,103)
    $status.Size = New-Object Drawing.Size -ArgumentList ([Math]::Max(500, ([int]$form.ClientSize.Width - 360))),44
    $status.TextAlign = 'MiddleLeft'
    $status.AutoEllipsis = $false

    $progress.Location = New-Object Drawing.Point(31,149)
    $progress.Width = [Math]::Max(500, ([int]$form.ClientSize.Width - 360))

    $chooser.Location = New-Object Drawing.Point(20,95)
    $chooser.Size = New-Object Drawing.Size -ArgumentList ($form.ClientSize.Width - 40),($form.ClientSize.Height - 120)

    Set-MailingWorkAreaVisible $true
    $chooser.Visible = $false

    $backButton.Location = New-Object Drawing.Point -ArgumentList ($form.ClientSize.Width - 285),100
    $backButton.Visible = $true
    $backButton.BringToFront()
}

function Clear-PreparedOutbox {
    try {
        New-Item -ItemType Directory -Force -Path $OutboxRoot | Out-Null
        Get-ChildItem -LiteralPath $OutboxRoot -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    } catch {}
}

function Get-ModeDisplayName {
    param([string]$Mode)
    switch ($Mode) {
        'JKH' { return 'ЖКХ' }
        'CAP' { return 'капремонт' }
        'ALL' { return 'ЖКХ + капремонт' }
        default { return '' }
    }
}

function Get-ModeMailText {
    param([string]$Mode)
    switch ($Mode) {
        'JKH' { return 'квитанции ЖКХ' }
        'CAP' { return 'квитанции капремонта' }
        'ALL' { return 'квитанции ЖКХ и капремонта' }
        default { return 'квитанции' }
    }
}

function Set-ReceiptMode {
    param([Parameter(Mandatory=$true)][string]$Mode)
    if (-not $script:scan) { return }

    switch ($Mode) {
        'JKH' { $items = @($script:scan.Items) }
        'CAP' { $items = @($script:scan.CapItems) }
        'ALL' { $items = @($script:scan.AllItems) }
        default { return }
    }

    $script:currentMode = $Mode
    $script:currentItems = @($items)
    $chooser.Visible = $false
    Show-FullMailingView
    $grid.Rows.Clear()
    $script:allSelected = $true
    $grid.Columns['Selected'].HeaderText = '☑'
    $savedRecipients = Load-Recipients

    foreach ($item in @($script:currentItems)) {
        $apt = if ([string]::IsNullOrWhiteSpace([string]$item.Apartment)) { 'не определена' } else { [string]$item.Apartment }
        $account = [string]$item.Account
        $recipient = ''
        $savedEmail = ''
        $savedWa = ''
        if ($savedRecipients.ContainsKey($account)) {
            $recipient = [string]$savedRecipients[$account].Recipient
            $savedEmail = [string]$savedRecipients[$account].Email
            $savedWa = [string]$savedRecipients[$account].WhatsApp
        }

        $index = $grid.Rows.Add()
        $row = $grid.Rows[$index]
        $row.Cells['Selected'].Value = $true
        $row.Cells['Apartment'].Value = $apt
        $row.Cells['Period'].Value = [string]$item.Period
        $row.Cells['Type'].Value = [string]$item.Type
        $row.Cells['Recipient'].Value = $recipient
        $row.Cells['Email'].Value = $savedEmail
        $row.Cells['WhatsApp'].Value = $savedWa
        $row.Cells['PdfName'].Value = [string]$item.PdfName
        $row.Tag = $account
    }

    Update-RecipientMode
    $count = @($script:currentItems).Count
    $jkhCount = [int]$script:scan.JkhCount
    $capCount = [int]$script:scan.CapCount
    $modeName = Get-ModeDisplayName $Mode

    if ($count -gt 0) {
        try {
            $autoPrepared = Prepare-Outbox @($script:currentItems) ([string]$script:scan.Period)
            Load-PreparedFilesIntoGrid $autoPrepared
            $status.Text = "✓ Период: $($script:scan.Period) • Найдено: ЖКХ $jkhCount, капремонт $capCount • Режим: $modeName • К отправке готово: $count"
            $status.ForeColor = [Drawing.Color]::Green
        }
        catch {
            $status.Text = "✖ Период: $($script:scan.Period) • Режим: $modeName • ошибка подготовки PDF"
            $status.ForeColor = [Drawing.Color]::DarkRed
        }
    }
    else {
        $status.Text = "✖ Период: $($script:scan.Period) • В режиме «$modeName» квитанций не найдено"
        $status.ForeColor = [Drawing.Color]::DarkRed
    }

    $emailButton.Enabled = ($count -gt 0)
    $waButton.Enabled = ($count -gt 0)
    $prepareButton.Enabled = ($count -gt 0)
    $title.Text = 'Рассылка квитанций — ' + $modeName
    $backButton.Focus()
}

$chooseJkh.Add_Click({ Set-ReceiptMode 'JKH' })
$chooseCap.Add_Click({ Set-ReceiptMode 'CAP' })
$chooseAll.Add_Click({ Set-ReceiptMode 'ALL' })

$backButton.Add_Click({
    try { Save-GridRecipients } catch {}
    Clear-PreparedOutbox
    $script:currentMode = ''
    $script:currentItems = @()
    $grid.Rows.Clear()
    $script:allSelected = $true
    $grid.Columns['Selected'].HeaderText = '☑'
    $emailButton.Enabled = $false
    $waButton.Enabled = $false
    $prepareButton.Enabled = $false
    $title.Text = 'Рассылка квитанций'
    $backButton.Visible = $false
    if ($script:scan) {
        $chooserInfo.Text = "Период: $($script:scan.Period) • Найдено: ЖКХ $($script:scan.JkhCount), капремонт $($script:scan.CapCount)"
    }
    Show-CompactChooser
    $chooser.Invalidate()
    $chooser.Refresh()
})

Show-CompactChooser

$token = [guid]::NewGuid().ToString('N')
$resultFile = Join-Path $env:TEMP ("domlight_scan_$token.json")
$errorFile = Join-Path $env:TEMP ("domlight_scan_$token.err.txt")
$script:process = $null
$script:started = $null
$script:scan = $null

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
    if (-not $script:process) { return }

    if (-not $script:process.HasExited) {
        $seconds = [int]((Get-Date) - $script:started).TotalSeconds
        $status.Text = "Проверяю последние квитанции… $seconds сек."
        return
    }

    $timer.Stop()
    $progress.Visible = $false

    if (Test-Path $resultFile) {
        $script:scan = Get-Content $resultFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $jkhCount = [int]$script:scan.JkhCount
        $capCount = [int]$script:scan.CapCount
        $readErrors = [int]$script:scan.ReadErrorCount
        $blankTexts = [int]$script:scan.BlankTextCount

        if (($jkhCount + $capCount) -gt 0) {
            $chooserInfo.Text = "Период: $($script:scan.Period) • Найдено: ЖКХ $jkhCount, капремонт $capCount"
            $chooserInfo.ForeColor = [Drawing.Color]::DimGray
            $chooseJkh.Enabled = ($jkhCount -gt 0)
            $chooseCap.Enabled = ($capCount -gt 0)
            $chooseAll.Enabled = (($jkhCount + $capCount) -gt 0)
            $status.Text = "✓ Период: $($script:scan.Period) • Найдено: ЖКХ $jkhCount, капремонт $capCount • Выберите, что подготовить"
            $status.ForeColor = [Drawing.Color]::Green
            $prepareButton.Enabled = $false
            $emailButton.Enabled = $false
            $waButton.Enabled = $false
            Show-CompactChooser
        }
        elseif ($readErrors -gt 0 -or $blankTexts -gt 0) {
            $first = ''
            if (@($script:scan.Errors).Count -gt 0) { $first = [string]@($script:scan.Errors)[0] }
            $chooserInfo.Text = "PDF не прочитаны. Ошибок: $readErrors, пустого текста: $blankTexts. $first"
            $chooserInfo.ForeColor = [Drawing.Color]::DarkRed
            $status.Text = '✖ ' + $chooserInfo.Text
            $status.ForeColor = [Drawing.Color]::DarkRed
        }
        else {
            $chooserInfo.Text = "Период: $($script:scan.Period) • Квитанции ЖКХ и капремонта не найдены"
            $chooserInfo.ForeColor = [Drawing.Color]::DarkRed
            $status.Text = '✖ ' + $chooserInfo.Text
            $status.ForeColor = [Drawing.Color]::DarkRed
        }
    }
    else {
        if (Test-Path $errorFile) {
            $message = (Get-Content $errorFile -Raw -Encoding UTF8).Trim()
        }
        else {
            $message = 'Нет результата анализа.'
        }

        if ($message.Length -gt 300) {
            $message = $message.Substring(0,300) + '…'
        }
        $status.Text = '✖ ' + $message
        $status.ForeColor = [Drawing.Color]::DarkRed
    }

    Remove-Item $resultFile, $errorFile -Force -ErrorAction SilentlyContinue
})

$form.Add_Shown({
    $status.Text = 'Проверяю последние квитанции…'
    $status.ForeColor = [Drawing.Color]::Black
    $progress.Visible = $true
    $script:started = Get-Date

    if (-not (Test-Path $ScannerFile)) {
        $progress.Visible = $false
        $status.Text = '✖ Не найден ReceiptScanner.ps1'
        $status.ForeColor = [Drawing.Color]::DarkRed
        return
    }

    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = 'powershell.exe'
    $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $ScannerFile + '" -ReceiptsDir "' + $ReceiptsDir + '" -ResultFile "' + $resultFile + '" -ErrorFile "' + $errorFile + '"'
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    try {
        $script:process = [Diagnostics.Process]::Start($psi)
        $timer.Start()
    }
    catch {
        $progress.Visible = $false
        $status.Text = '✖ Не удалось запустить анализ: ' + $_.Exception.Message
        $status.ForeColor = [Drawing.Color]::DarkRed
    }
})

$form.Add_FormClosed({
    try { if ($script:mailingMutex) { $script:mailingMutex.ReleaseMutex(); $script:mailingMutex.Dispose() } } catch {}
    try { Save-GridRecipients } catch {}
    try { $timer.Stop() } catch {}
    if ($script:process -and -not $script:process.HasExited) {
        try { $script:process.Kill() } catch {}
    }
    Remove-Item $resultFile, $errorFile -Force -ErrorAction SilentlyContinue
})

$grid.Add_CellDoubleClick({
    param($sender, $e)

    if ($e.RowIndex -lt 0) { return }
    if ($grid.Columns[$e.ColumnIndex].Name -ne 'PdfName') { return }

    $row = $grid.Rows[$e.RowIndex]
    $file = [string]$row.Cells['PdfName'].Tag

    if (-not [string]::IsNullOrWhiteSpace($file) -and (Test-Path $file)) {
        try { Start-Process -FilePath $file } catch {}
    }
})

$grid.Add_CellContentClick({
    param($sender, $e)

    if ($e.RowIndex -lt 0) { return }

    $columnName = $grid.Columns[$e.ColumnIndex].Name
    if ($columnName -notin @('SendMail','SendWhatsApp','ViewPdf')) { return }

    $row = $grid.Rows[$e.RowIndex]
    $account = [string]$row.Tag

    if ($columnName -eq 'ViewPdf') {
        $file = [string]$row.Cells['PdfName'].Tag

        if ([string]::IsNullOrWhiteSpace($file) -or -not (Test-Path $file)) {
            $scanItem = Get-ScanItemForRow $row
            if (-not $scanItem) {
                [Windows.Forms.MessageBox]::Show(
                    'Не найдена квитанция для этой строки.',
                    'PDF',
                    'OK',
                    'Warning'
                ) | Out-Null
                return
            }

            $prepared = Prepare-Outbox @($scanItem) ([string]$script:scan.Period)
            $file = [string]@($prepared.Items)[0].File
            $row.Cells['PdfName'].Value = [IO.Path]::GetFileName($file)
            $row.Cells['PdfName'].Tag = $file
        }

        try {
            # Open with the user's default PDF application.
            Start-Process -FilePath $file
        }
        catch {
            try {
                Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $file + '"')
            }
            catch {
                [Windows.Forms.MessageBox]::Show(
                    "Не удалось открыть PDF:`r`n$($_.Exception.Message)",
                    'PDF',
                    'OK',
                    'Error'
                ) | Out-Null
            }
        }
        return
    }

    if ($one.Checked) {
        [Windows.Forms.MessageBox]::Show(
            'Сейчас выбран режим «Все одному получателю». Для него используются большие кнопки внизу.',
            'Отправка',
            'OK',
            'Information'
        ) | Out-Null
        return
    }

    Save-GridRecipients

    $apartment = [string]$row.Cells['Apartment'].Value
    $rowType = [string]$row.Cells['Type'].Value
    $rowEmail = [string]$row.Cells['Email'].Value
    $rowWa = [string]$row.Cells['WhatsApp'].Value

    $scanItem = Get-ScanItemForRow $row
    if (-not $scanItem) {
        [Windows.Forms.MessageBox]::Show(
            'Не найдена квитанция для этой строки.',
            'Отправка',
            'OK',
            'Warning'
        ) | Out-Null
        return
    }

    $file = [string]$row.Cells['PdfName'].Tag
    if ([string]::IsNullOrWhiteSpace($file) -or -not (Test-Path $file)) {
        $prepared = Prepare-Outbox @($scanItem) ([string]$script:scan.Period)
        $file = [string]@($prepared.Items)[0].File
        $row.Cells['PdfName'].Value = [IO.Path]::GetFileName($file)
        $row.Cells['PdfName'].Tag = $file
    }

    if ($columnName -eq 'SendMail') {
        if ([string]::IsNullOrWhiteSpace($rowEmail)) {
            [Windows.Forms.MessageBox]::Show(
                'Введите E-mail в этой строке.',
                'Mail',
                'OK',
                'Warning'
            ) | Out-Null
            return
        }

        Gmail-Send `
            $rowEmail `
            ("Квитанция " + $rowType + " — кв. " + $apartment) `
            ("Добрый день.`r`nНаправляю квитанцию " + $rowType + " во вложении.") `
            @($file)
        return
    }

    if ($columnName -eq 'SendWhatsApp') {
        if ([string]::IsNullOrWhiteSpace($rowWa)) {
            [Windows.Forms.MessageBox]::Show(
                'Введите номер WhatsApp в этой строке.',
                'WhatsApp',
                'OK',
                'Warning'
            ) | Out-Null
            return
        }

        WhatsApp-Open `
            $rowWa `
            ("Добрый день. Направляю квитанцию " + $rowType + " по квартире " + $apartment + '.') `
            @($file)
    }
})

$prepareButton.Add_Click({
    if (-not $script:scan) { return }
    Save-GridRecipients

    try {
        # Prepare the complete set for the currently selected receipt mode.
        $prepared = Prepare-Outbox @($script:currentItems) ([string]$script:scan.Period)
        Load-PreparedFilesIntoGrid $prepared
        Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $prepared.Folder + '"')
    }
    catch {
        [Windows.Forms.MessageBox]::Show(
            "Не удалось подготовить PDF:`r`n$($_.Exception.Message)",
            'Подготовка PDF',
            'OK',
            'Error'
        ) | Out-Null
    }
})

$outboxButton.Add_Click({
    try {
        New-Item -ItemType Directory -Force -Path $OutboxRoot | Out-Null
        Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $OutboxRoot + '"')
    }
    catch {
        [Windows.Forms.MessageBox]::Show(
            "Не удалось открыть папку:`r`n$($_.Exception.Message)",
            'Папка подготовленных',
            'OK',
            'Error'
        ) | Out-Null
    }
})

$emailButton.Add_Click({
    if (-not $script:scan) { return }
    Save-GridRecipients

    $selectedItems = Require-SelectedScanItems
    if ($null -eq $selectedItems) { return }

    $prepared = Prepare-Outbox @($selectedItems) ([string]$script:scan.Period)

    if ($one.Checked) {
        if ([string]::IsNullOrWhiteSpace($email.Text)) {
            [Windows.Forms.MessageBox]::Show('Введите E-mail получателя.','E-mail','OK','Warning') | Out-Null
            return
        }

        $mailText = Get-ModeMailText $script:currentMode
        Gmail-Send `
            $email.Text `
            ("Квитанции — " + [string]$script:scan.Period) `
            ("Добрый день.`r`nНаправляю " + $mailText + " во вложении.") `
            @($prepared.Items | ForEach-Object { $_.File })
    }
    else {
        $map = Load-Recipients
        $missing = @()

        foreach ($group in @($prepared.Items | Group-Object Account)) {
            $account = [string]$group.Name
            $groupItems = @($group.Group)
            $apartment = [string]$groupItems[0].Apartment
            if ($map.ContainsKey($account) -and -not [string]::IsNullOrWhiteSpace([string]$map[$account].Email)) {
                $types = @($groupItems | ForEach-Object { [string]$_.Type } | Select-Object -Unique)
                $typeText = if ($types.Count -gt 1) { 'ЖКХ и капремонт' } else { [string]$types[0] }
                Gmail-Send `
                    ([string]$map[$account].Email) `
                    ("Квитанции — кв. " + $apartment) `
                    ("Добрый день.`r`nНаправляю квитанции: " + $typeText + ".") `
                    @($groupItems | ForEach-Object { $_.File })
            }
            else {
                $missing += $apartment
            }
        }

        if ($missing.Count -gt 0) {
            [Windows.Forms.MessageBox]::Show(
                'Не указан E-mail для: ' + ($missing -join ', '),
                'Получатели',
                'OK',
                'Warning'
            ) | Out-Null
        }
    }
})

$waButton.Add_Click({
    if (-not $script:scan) { return }
    Save-GridRecipients

    $selectedItems = Require-SelectedScanItems
    if ($null -eq $selectedItems) { return }

    $prepared = Prepare-Outbox @($selectedItems) ([string]$script:scan.Period)

    if ($one.Checked) {
        WhatsApp-Open `
            $wa.Text `
            ("Добрый день. Направляю " + (Get-ModeMailText $script:currentMode) + " за " + [string]$script:scan.Period + '.') `
            @($prepared.Items | ForEach-Object { $_.File })
    }
    else {
        $map = Load-Recipients
        $missing = @()

        foreach ($group in @($prepared.Items | Group-Object Account)) {
            $account = [string]$group.Name
            $groupItems = @($group.Group)
            $apartment = [string]$groupItems[0].Apartment
            if ($map.ContainsKey($account) -and -not [string]::IsNullOrWhiteSpace([string]$map[$account].WhatsApp)) {
                $types = @($groupItems | ForEach-Object { [string]$_.Type } | Select-Object -Unique)
                $typeText = if ($types.Count -gt 1) { 'ЖКХ и капремонт' } else { [string]$types[0] }
                WhatsApp-Open `
                    ([string]$map[$account].WhatsApp) `
                    ("Добрый день. Направляю квитанции " + $typeText + " по квартире " + $apartment + '.') `
                    @($groupItems | ForEach-Object { $_.File })
            }
            else {
                $missing += $apartment
            }
        }

        if ($missing.Count -gt 0) {
            [Windows.Forms.MessageBox]::Show(
                'Не указан WhatsApp для: ' + ($missing -join ', '),
                'Получатели',
                'OK',
                'Warning'
            ) | Out-Null
        }
    }
})

[void]$form.ShowDialog()
