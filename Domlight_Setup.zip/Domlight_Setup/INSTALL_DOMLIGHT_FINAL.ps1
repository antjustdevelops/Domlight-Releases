﻿$ErrorActionPreference = 'Stop'

$Root = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Domlight'
$Payload = Join-Path $PSScriptRoot 'payload'
$Desktop = [Environment]::GetFolderPath('Desktop')

if (-not (Test-Path $Payload)) {
    [Windows.Forms.MessageBox]::Show(
        'Не найдена папка payload рядом с установщиком.',
        'Domlight',
        'OK',
        'Error'
    ) | Out-Null
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

try {
    New-Item -ItemType Directory -Force -Path $Root | Out-Null
    $Data = Join-Path $Root 'data'
    New-Item -ItemType Directory -Force -Path $Data | Out-Null

    # Stop known Domlight helper processes only when their command line points to Domlight.
    try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object {
                $_.CommandLine -and
                $_.CommandLine -like '*\Domlight\*' -and
                ($_.Name -match 'powershell|wscript|cscript')
            } |
            ForEach-Object {
                try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {}
            }
    } catch {}

    # Remove old application files, but NEVER delete data.
    Get-ChildItem -LiteralPath $Root -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne 'data' } |
        ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }

    # Copy the final application payload.
    Copy-Item -Path (Join-Path $Payload '*') -Destination $Root -Recurse -Force

    # Create a single desktop shortcut.
    $shortcutPath = Join-Path $Desktop 'Domlight.lnk'
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
    $shortcut.Arguments = '"' + (Join-Path $Root 'DomlightLauncher.vbs') + '"'
    $shortcut.WorkingDirectory = $Root
    $icon = Join-Path $Root 'Domlight.ico'
    if (Test-Path $icon) {
        $shortcut.IconLocation = $icon
    }
    $shortcut.Save()

    # Remove obsolete alternate desktop shortcuts created by older builds.
    foreach ($name in @(
        'START_DOMLIGHT.lnk',
        'Domlight - Рассылка.lnk',
        'Domlight old.lnk'
    )) {
        $p = Join-Path $Desktop $name
        if (Test-Path $p) {
            Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
        }
    }

    [Windows.Forms.MessageBox]::Show(
        "Domlight установлен/обновлён.`r`n`r`n" +
        "Ваши квитанции, получатели, история E-mail/WhatsApp, Google OAuth и другие данные в папке data сохранены.`r`n`r`n" +
        "На рабочем столе используйте только ярлык Domlight.",
        'Domlight — готово',
        'OK',
        'Information'
    ) | Out-Null
}
catch {
    [Windows.Forms.MessageBox]::Show(
        "Не удалось установить Domlight:`r`n`r`n$($_.Exception.Message)",
        'Domlight',
        'OK',
        'Error'
    ) | Out-Null
    exit 1
}
